﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Restaurant
{



    public partial class Restaurant : Form
    {
        //-------数値設定-------------------------
        private string name;            //オブジェクトに覚えさせる商品名
        private int price;              //商品価格
        private int count;              //購入数
        private int pay = 0;            //客側支払金額
        private Label[,] textList;
        private static double taxRate = 0.1;

        List<Restaurant> basket = new List<Restaurant>();//購入商品を順番に納めるList
        private static int totalPrice = 0;              //税込合計購入金額
        int[] realMoneyCount = new int[9];              //現金支払時の、金種ごとの受領枚数
        readonly int[] tanka = { 10000, 5000, 1000, 500, 100, 50, 10, 5, 1};//金種を納めた配列
        readonly int DISPLAY_LIMIT = 9;//画面に表示できる商品数の上限
        int[] DrawerStock = { 0, 20, 100, 100, 100, 100, 100, 100, 100 };//ドロア内釣りストック
        
        public Restaurant()
        {
            InitializeComponent();
            DetachPanels();
            MenuPanel.BringToFront();
            WarningPlate();
            emoney.Checked = true;
            textList = new Label[,]
            {
                {Line0_0, Line0_1, Line0_2, Line0_3},
                {Line1_0, Line1_1, Line1_2, Line1_3},
                {Line2_0, Line2_1, Line2_2, Line2_3},
                {Line3_0, Line3_1, Line3_2, Line3_3},
                {Line4_0, Line4_1, Line4_2, Line4_3},
                {Line5_0, Line5_1, Line5_2, Line5_3},
                {Line6_0, Line6_1, Line6_2, Line6_3},
                {Line7_0, Line7_1, Line7_2, Line7_3},
                {Line8_0, Line8_1, Line8_2, Line8_3}
            };
        }

        private void DetachPanels()
        {
            DrawerPanel.Parent = this;
            MenuPanel.Parent = this;
            DrawerPanel.Location = new Point(21, 30);
            MenuPanel.Location = new Point(20, 30); 
        }

        private void WarningPlate()
        {
            Warning.Parent = this;
        }

        public Restaurant(string name, int price)
        {
            this.name = name;
            this.price = price;
            this.count = 1;//新規に購入した商品なので、その個数は必ず１個になる

        }

        private string getName()
        {
            return this.name;
        }

        private int getPrice()
        {
            return this.price;
        }



        //-------メニューリスト-------------------------
        static string[] menuName = {
                            "赤グラスワイン",     "辛味チキン",      "ポテトのグリル",    "小エビのサラダ",   "わかめのサラダ",        "ほうれん草のソテー",
                            "マルゲリータ",       "ミラノ風ドリア",  "ソーセージピザ",    "カルボナーラ",     "ペペロンチーノ",        "ミートソース",
                            "ハンバーグステーキ", "ミックスグリル",  "フォッカチオ",      "ドリンクバー",     "イタリアンジェラート",  "ティラミスクラシコ"
                            };


        //-------商品名と価格を納めたDictionary-------------------------
        private static List<Restaurant> menu { get; } = new List<Restaurant>
        {
                {new Restaurant(menuName[0], 91) },   {new Restaurant(menuName[1], 273) },  {new Restaurant(menuName[2], 273) },
                {new Restaurant(menuName[3], 319 )},  {new Restaurant(menuName[4], 319) },  {new Restaurant(menuName[5], 182) },
                {new Restaurant(menuName[6], 364 )},  {new Restaurant(menuName[7], 273) },  {new Restaurant(menuName[8], 364) },
                {new Restaurant(menuName[9], 455) },  {new Restaurant(menuName[10], 273) }, {new Restaurant(menuName[11], 364) },
                {new Restaurant(menuName[12], 364) }, {new Restaurant(menuName[13], 591) }, {new Restaurant(menuName[14], 137) },
                {new Restaurant(menuName[15], 273) }, {new Restaurant(menuName[16], 228) }, {new Restaurant(menuName[17], 273) },
        };

        //-------新しいメニューを購入し、購入品目リストが増えたときの処理-------
        private Label[,] NewMenuBuy(List<Restaurant> basket ,int index, Label[,] list)
        {
            if(index < DISPLAY_LIMIT)
            {
                list[index, 0].Text = basket[index].name; list[index, 1].Text = basket[index].price.ToString();
                list[index, 2].Text = basket[index].count.ToString(); list[index, 3].Text = (basket[index].price * basket[index].count).ToString();
            }
            return list;
        }

        //-------キャンセルボタンを押したときの削除処理-------
        //basketはキャンセル前のバスケットの中身、countは「0から始めて何行目の商品」を消したいか、labelは二次元ラベル
        private Label[,] cancelUpdate(List<Restaurant> basket, int delete_line, Label[,] label)
        {
            for (int i = 0; i < DISPLAY_LIMIT; i++)
            {
                if (i < basket.Count)
                {
                    label[i, 0].Text = basket[i].name;
                    label[i, 1].Text = (basket[i].count).ToString();
                    label[i, 2].Text = (basket[i].price).ToString();
                    label[i, 3].Text = (basket[i].price * basket[i].count).ToString();
                }
                else
                {
                    label[i, 0].Text = "";
                    label[i, 1].Text = "";
                    label[i, 2].Text = "";
                    label[i, 3].Text = "";
                }
            }
            return label;
        }

        private string[] cancelMoneyUpdate(Label[,] testList)
        {
            int subTotal = 0;
            int tax = 0;
            int total = 0;
            for(int i = 0; i< basket.Count;  i++)
            {
                subTotal += basket[i].price * basket[i].count;
            }
            tax = (int)(Math.Round((double)subTotal * taxRate));
            total = subTotal + tax;
            string a = subTotal.ToString(); string b = tax.ToString(); string c = total.ToString();
            return  new string[]{ a, b, c };
        }

        //-------現金購入時、入力金額を手打ちで更新した際の処理-------
        private int realMoney(int[] money, int[] tanka)
        {
            int a = 0;
            for(int i = 0; i < money.Length; i++)
            {
                a += money[i] * tanka[i];
            }
            return a;
        }

        //-------小計・合計更新に関する処理-------
        private string[] totalUpdate(int pr, int totalPrice)
        {
            totalPrice += pr;
            string subt_Text = totalPrice.ToString();//税抜き価格
            int mid = (int)(Math.Round(((double)totalPrice) * taxRate));
            string t_Text = (totalPrice + mid).ToString();//税込価格
            string taxText = mid.ToString();//税額
            string[] SubTotal = {subt_Text, t_Text, taxText};
            return SubTotal;
        }


        private void topic_Click(object sender, EventArgs e)
        {
            string nm = ""; int pr = 0;
            if (sender is System.Windows.Forms.Button topic)
                switch (topic.Name)
                {
                    case "topic01": { nm = menu[0].getName();  pr = menu[0].getPrice(); break; }
                    case "topic02": { nm = menu[1].getName();  pr = menu[1].getPrice(); break; }
                    case "topic03": { nm = menu[2].getName();  pr = menu[2].getPrice(); break; }
                    case "topic04": { nm = menu[3].getName();  pr = menu[3].getPrice(); break; }
                    case "topic05": { nm = menu[4].getName();  pr = menu[4].getPrice(); break; }
                    case "topic06": { nm = menu[5].getName();  pr = menu[5].getPrice(); break; }
                    case "topic07": { nm = menu[6].getName();  pr = menu[6].getPrice(); break; }
                    case "topic08": { nm = menu[7].getName();  pr = menu[7].getPrice(); break; }
                    case "topic09": { nm = menu[8].getName();  pr = menu[8].getPrice(); break; }
                    case "topic10": { nm = menu[9].getName();  pr = menu[9].getPrice(); break; }
                    case "topic11": { nm = menu[10].getName(); pr = menu[10].getPrice(); break; }
                    case "topic12": { nm = menu[11].getName(); pr = menu[11].getPrice(); break; }
                    case "topic13": { nm = menu[12].getName(); pr = menu[12].getPrice(); break; }
                    case "topic14": { nm = menu[13].getName(); pr = menu[13].getPrice(); break; }
                    case "topic15": { nm = menu[14].getName(); pr = menu[14].getPrice(); break; }
                    case "topic16": { nm = menu[15].getName(); pr = menu[15].getPrice(); break; }
                    case "topic17": { nm = menu[16].getName(); pr = menu[16].getPrice(); break; }
                    case "topic18": { nm = menu[17].getName(); pr = menu[17].getPrice(); break; }
                }

            bool topic1_bool = basket.Any(item => item.name == nm);//購入バスケット内に買ったものがないか走査
            int index = 0;
            if (topic1_bool)//すでに同じものがあったら、購入数に+1
            {
                var Item = basket.First(item => item.name == nm);
                Item.count++;
                index = basket.FindIndex(item => item == Item);
            }
            else//無かったらbasketに赤グラスワインを追加
            {
                basket.Add(new Restaurant(nm, pr));
                index = basket.Count - 1;
            }
            DrawerButton.Enabled = false;//バスケットに何か入ったらドロワ開閉禁止

            //購入品目リストの数字を更新する

            textList = NewMenuBuy(basket, index, textList);

            //次は購入品目に今購入したものがあるかどうかチェックする
            //存在しなければ空いている欄に新しい商品を追加
            //いずれにしても品目、購入数、合計金額を更新
            string[] newSubtotal = totalUpdate(pr, totalPrice);
            subtotal.Text = newSubtotal[0];
            total.Text = newSubtotal[1];
            tax.Text = newSubtotal[2];
            totalPrice = int.Parse(newSubtotal[1]);
        }

        //-------キャンセルボタンを押した際の処理-------
        private void Cancel0_Click(object sender, EventArgs e)
        {
            if(basket.Count ==1) DrawerButton.Enabled = true;

            if (basket.Count > 0)
            {
                basket.RemoveAt(0);
                textList = cancelUpdate(basket, 0, textList);
                string[] s = cancelMoneyUpdate(textList);
                subtotal.Text = s[0]; tax.Text = s[1]; total.Text = s[2]; totalPrice = int.Parse(s[2]);
            }
        }

        private void Cancel1_Click(object sender, EventArgs e)
        {
            if (basket.Count > 1)
            {
                basket.RemoveAt(1);
                textList = cancelUpdate(basket, 1, textList);
                string[] s = cancelMoneyUpdate(textList);
                subtotal.Text = s[0]; tax.Text = s[1]; total.Text = s[2]; totalPrice = int.Parse(s[2]);
            }
        }

        private void Cancel2_Click(object sender, EventArgs e)
        {
            if (basket.Count > 2)
            {
                basket.RemoveAt(2);
                textList = cancelUpdate(basket, 2, textList);
                string[] s = cancelMoneyUpdate(textList);
                subtotal.Text = s[0]; tax.Text = s[1]; total.Text = s[2]; totalPrice = int.Parse(s[2]);
            }
        }

        private void Cancel3_Click(object sender, EventArgs e)
        {
            if (basket.Count > 3)
            {
                basket.RemoveAt(3);
                textList = cancelUpdate(basket, 3, textList);
                string[] s = cancelMoneyUpdate(textList);
                subtotal.Text = s[0]; tax.Text = s[1]; total.Text = s[2]; totalPrice = int.Parse(s[2]);
            }
        }

        private void Cancel4_Click(object sender, EventArgs e)
        {
            if (basket.Count > 4)
            {
                basket.RemoveAt(4);
                textList = cancelUpdate(basket, 4, textList);
                string[] s = cancelMoneyUpdate(textList);
                subtotal.Text = s[0]; tax.Text = s[1]; total.Text = s[2]; totalPrice = int.Parse(s[2]);
            }
        }

        private void Cancel5_Click(object sender, EventArgs e)
        {
            if (basket.Count > 5)
            {
                basket.RemoveAt(5);
                textList = cancelUpdate(basket, 5, textList);
                string[] s = cancelMoneyUpdate(textList);
                subtotal.Text = s[0]; tax.Text = s[1]; total.Text = s[2]; totalPrice = int.Parse(s[2]);
            }
        }

        private void Cancel6_Click(object sender, EventArgs e)
        {
            if (basket.Count > 6)
            {
                basket.RemoveAt(6);
                textList = cancelUpdate(basket, 6, textList);
                string[] s = cancelMoneyUpdate(textList);
                subtotal.Text = s[0]; tax.Text = s[1]; total.Text = s[2]; totalPrice = int.Parse(s[2]);
            }
        }

        private void Cancel7_Click(object sender, EventArgs e)
        {
            if (basket.Count > 7)
            {
                basket.RemoveAt(7);
                textList = cancelUpdate(basket, 7, textList);
                string[] s = cancelMoneyUpdate(textList);
                subtotal.Text = s[0]; tax.Text = s[1]; total.Text = s[2]; totalPrice = int.Parse(s[2]);
            }
        }

        private void Cancel8_Click(object sender, EventArgs e)
        {
            if (basket.Count > 8)
            {
                basket.RemoveAt(8);
                textList = cancelUpdate(basket, 8, textList);
                string[] s = cancelMoneyUpdate(textList);
                subtotal.Text = s[0]; tax.Text = s[1]; total.Text = s[2]; totalPrice = int.Parse(s[2]);
            }
        }

        

        private void emoney_CheckedChanged(object sender, EventArgs e)//支払を電子マネーに切り替える
        {
            eMoneyPanel.Enabled = true;
            eMoneyPanel.Visible = true;
            cashPanel.Enabled = false;
            cashPanel.Visible = false;
            eMoneyPanel.BringToFront();

            pmnt.Text = "0";
            sheet_10k.Text = "0"; sheet5000.Text = "0"; sheet1000.Text = "0"; coin500.Text = "0"; coin100.Text = "0";
            coin50.Text = "0"; coin10.Text = "0"; coin5.Text = "0"; coin1.Text = "0";
        }
        private void cash_CheckedChanged(object sender, EventArgs e)//支払を現金に切り替える
        {
            eMoneyPanel.Enabled = false;
            eMoneyPanel.Visible = false;
            cashPanel.Enabled = true;
            cashPanel.Visible = true;
            cashPanel.BringToFront();
            
            pmnt.Text = "0";
            int p = 0;
            realMoneyCount = new int[9];
            pmnt.Text = p.ToString();
        }

        private async void mn1_Click(object sender, EventArgs e)
        {
            pay *= 10;
            pay += 1;
            if (pay > 1_000_000)
            {
                ErrorCage.Text = "最大入力数値を超えました";
                pay = 0;
                await Task.Delay(5000);
                ErrorCage.Text = "";
            }
            pmnt.Text = pay.ToString();
        }

        private async void mn2_Click(object sender, EventArgs e)
        {
            pay *= 10;
            pay += 2;
            if (pay > 1_000_000)
            {
                ErrorCage.Text = "最大入力数値を超えました";
                pay = 0;
                await Task.Delay(5000);
                ErrorCage.Text = "";
            }
            pmnt.Text = pay.ToString();
        }

        private async void mn3_Click(object sender, EventArgs e)
        {
            pay *= 10;
            pay += 3;
            if (pay > 1_000_000)
            {
                ErrorCage.Text = "最大入力数値を超えました";
                pay = 0;
                await Task.Delay(5000);
                ErrorCage.Text = "";
            }
            pmnt.Text = pay.ToString();
        }

        private async void mn4_Click(object sender, EventArgs e)
        {
            pay *= 10;
            pay += 4;
            if (pay > 1_000_000)
            {
                ErrorCage.Text = "最大入力数値を超えました";
                pay = 0;
                await Task.Delay(5000);
                ErrorCage.Text = "";
            }
            pmnt.Text = pay.ToString();
        }

        private async void mn5_Click(object sender, EventArgs e)
        {
            pay *= 10;
            pay += 5;
            if (pay > 1_000_000)
            {
                ErrorCage.Text = "最大入力数値を超えました";
                pay = 0;
                await Task.Delay(5000);
                ErrorCage.Text = "";
            }
            pmnt.Text = pay.ToString();
        }

        private async void mn6_Click(object sender, EventArgs e)
        {
            pay *= 10;
            pay += 6;
            if (pay > 1_000_000)
            {
                ErrorCage.Text = "最大入力数値を超えました";
                pay = 0;
                await Task.Delay(5000);
                ErrorCage.Text = "";
            }
            pmnt.Text = pay.ToString();
        }

        private async void mn7_Click(object sender, EventArgs e)
        {
            pay *= 10;
            pay += 7;
            if (pay > 1_000_000)
            {
                ErrorCage.Text = "最大入力数値を超えました";
                pay = 0;
                await Task.Delay(5000);
                ErrorCage.Text = "";
            }
            pmnt.Text = pay.ToString();
        }

        private async void mn8_Click(object sender, EventArgs e)
        {
            pay *= 10;
            pay += 8;
            if (pay > 1_000_000)
            {
                ErrorCage.Text = "最大入力数値を超えました";
                pay = 0;
                await Task.Delay(5000);
                ErrorCage.Text = "";
            }
            pmnt.Text = pay.ToString();
        }

        private async void mn9_Click(object sender, EventArgs e)
        {
            pay *= 10;
            pay += 9;
            if (pay > 1_000_000)
            {
                ErrorCage.Text = "最大入力数値を超えました";
                pay = 0;
                await Task.Delay(5000);
                ErrorCage.Text = "";
            }
            pmnt.Text = pay.ToString();
        }

        private async void mn0_Click(object sender, EventArgs e)
        {
            pay *= 10;
            if (pay > 1_000_000)
            {
                ErrorCage.Text = "最大入力数値を超えました";
                pay = 0;
                await Task.Delay(5000);
                ErrorCage.Text = "";
            }
            pmnt.Text = pay.ToString();
        }

        private async void mn00_Click(object sender, EventArgs e)
        {
            pay *= 100;
            if (pay > 1_000_000)
            {
                ErrorCage.Text = "最大入力数値を超えました";
                pay = 0;
                await Task.Delay(5000);
                ErrorCage.Text = "";
            }
            pmnt.Text = pay.ToString();
        }

        private async void mn10_Click(object sender, EventArgs e)
        {
            pay += 10000;
            if (pay > 1_000_000)
            {
                ErrorCage.Text = "最大入力数値を超えました";
                pay = 0;
                await Task.Delay(5000);
                ErrorCage.Text = "";
            }
            pmnt.Text = pay.ToString();
        }

        //------------------取消ボタン---------------------------

        private void rmv_Click(object sender, EventArgs e)
        {
            pay = 0;
            pmnt.Text = pay.ToString();
            
        }

        //---------------------現金支払時の、枚数をTextで打ち込む操作群----------

        private void sheet_10k_TextChanged(object sender, EventArgs e)
        {
            try
            {
                realMoneyCount[0] = int.Parse(sheet_10k.Text);
                int money = realMoney(realMoneyCount,tanka);
                pmnt.Text = money.ToString();
            }
            catch (Exception)
            {
                realMoneyCount[0] = 0;
                int money = realMoney(realMoneyCount, tanka);
                pmnt.Text = money.ToString();
                sheet_10k.Text = "0";
            }
        }

        private void sheet5000_TextChanged(object sender, EventArgs e)
        {
            try
            {
                realMoneyCount[1] = int.Parse(sheet5000.Text);
                int money = realMoney(realMoneyCount, tanka);
                pmnt.Text = money.ToString();
            }
            catch (Exception) 
            {
                realMoneyCount[1] = 0;
                int money = realMoney(realMoneyCount, tanka);
                pmnt.Text = money.ToString();
                sheet5000.Text = "0";
            }


        }

        private void sheet1000_TextChanged(object sender, EventArgs e)
        {
            try
            {
                realMoneyCount[2] = int.Parse(sheet1000.Text);
                int money = realMoney(realMoneyCount, tanka);
                pmnt.Text = money.ToString();
            }
            catch (Exception)
            {
                realMoneyCount[2] = 0;
                int money = realMoney(realMoneyCount, tanka);
                pmnt.Text = money.ToString();
                sheet1000.Text = "0";
            }
        }

        private void coin500_TextChanged(object sender, EventArgs e)
        {
            try
            {
                realMoneyCount[3] = int.Parse(coin500.Text);
                int money = realMoney(realMoneyCount, tanka);
                pmnt.Text = money.ToString();
            }
            catch (Exception) 
            {
                realMoneyCount[3] = 0;
                int money = realMoney(realMoneyCount,tanka);
                pmnt.Text = money.ToString();
                coin500.Text = "0";
            }

        }

        private void coin100_TextChanged(object sender, EventArgs e)
        {
            try
            {
                realMoneyCount[4] = int.Parse(coin100.Text);
                int money = realMoney(realMoneyCount, tanka);
                pmnt.Text = money.ToString();
            }
            catch (Exception)
            {
                realMoneyCount[4] = 0;
                int money = realMoney(realMoneyCount, tanka);
                pmnt.Text = money.ToString();
                coin100.Text = "0";
            }
        }

        private void coin50_TextChanged(object sender, EventArgs e)
        {
            try
            {
                realMoneyCount[5] = int.Parse(coin50.Text);
                int money = realMoney(realMoneyCount, tanka);
                pmnt.Text = money.ToString();
                coin50.Text = "0";
            }
            catch (Exception)
            
            {
                realMoneyCount[5] = 0;
                int money = realMoney(realMoneyCount, tanka);
                pmnt.Text = money.ToString();
                coin50.Text = "0";
            }
        }

        private void coin10_TextChanged(object sender, EventArgs e)
        {
            try
            {
                realMoneyCount[6] = int.Parse(coin10.Text);
                int money = realMoney(realMoneyCount, tanka);
                pmnt.Text = money.ToString();
            }
            catch(Exception)
            {
                realMoneyCount[6] = 0;
                int money = realMoney(realMoneyCount, tanka);
                pmnt.Text = money.ToString();
                coin10.Text = "0";
            }
        }

        private void coin5_TextChanged(object sender, EventArgs e)
        {
            try
            {
                realMoneyCount[7] = int.Parse(coin5.Text);
                int money = realMoney(realMoneyCount, tanka);
                pmnt.Text = money.ToString();
            }
            catch (Exception)
            {
                realMoneyCount[7] = 0;
                int money = realMoney(realMoneyCount, tanka);
                pmnt.Text = money.ToString();
                coin5.Text = "0";
            }
        }

        private void coin1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                realMoneyCount[8] = int.Parse(coin1.Text);
                int money = realMoney(realMoneyCount, tanka);
                pmnt.Text = money.ToString();
            }
            catch (Exception)
            {
                realMoneyCount[8] = 0;
                int money = realMoney(realMoneyCount, tanka);
                pmnt.Text = money.ToString();
                coin1.Text = "0";
            }
        }

        //-----------------------ボタンで札、コイン数を変更できる--------------------------

        private void Up_Click(object sender, EventArgs e)
        {
            if (sender is System.Windows.Forms.Button UP)
            {
                switch (UP.Name)
                {
                    case "sheet10kUp":
                        {
                            realMoneyCount[0]++;
                            sheet_10k.Text = realMoneyCount[0].ToString();
                            break;
                        }
                    case "sheet5000Up":
                        {
                            realMoneyCount[1]++;
                            sheet5000.Text = realMoneyCount[1].ToString();
                            break;
                        }
                    case "sheet1000Up":
                        {
                            realMoneyCount[2]++;
                            sheet1000.Text = realMoneyCount[2].ToString();
                            break;
                        }
                    case "coin500Up":
                        {
                            realMoneyCount[3]++;
                            coin500.Text = realMoneyCount[3].ToString();
                            break;
                        }
                    case "coin100Up":
                        {
                            realMoneyCount[4]++;
                            coin100.Text = realMoneyCount[4].ToString();
                            break;
                        }
                    case "coin50Up":
                        {
                            realMoneyCount[5]++;
                            coin50.Text = realMoneyCount[5].ToString();
                            break;
                        }
                    case "coin10Up":
                        {
                            realMoneyCount[6]++;
                            coin10.Text = realMoneyCount[6].ToString();
                            break;
                        }
                    case "coin5Up":
                        {
                            realMoneyCount[7]++;
                            coin5.Text = realMoneyCount[7].ToString();
                            break;
                        }
                    case "coin1Up":
                        {
                            realMoneyCount[8]++;
                            coin1.Text = realMoneyCount[8].ToString();
                            break;
                        }
                }
            }
            pay = realMoney(realMoneyCount, tanka);
            pmnt.Text = pay.ToString();
        }
        private void Down_Click(object sender, EventArgs e)
        {
            if (sender is System.Windows.Forms.Button DOWN)
            {
                switch (DOWN.Name)
                {
                    case "sheet10kDown":
                        {
                            realMoneyCount[0] = Math.Max(--realMoneyCount[0], 0);
                            sheet_10k.Text = realMoneyCount[0].ToString();
                            break;
                        }
                    case "sheet5000Down":
                        {
                            realMoneyCount[1] = Math.Max(--realMoneyCount[1], 0);
                            sheet5000.Text = realMoneyCount[1].ToString();
                            break;
                        }
                    case "sheet1000Down":
                        {
                            realMoneyCount[2] = Math.Max(--realMoneyCount[2], 0);
                            sheet1000.Text = realMoneyCount[2].ToString();
                            break;
                        }
                    case "coin500Down":
                        {
                            realMoneyCount[3] = Math.Max(--realMoneyCount[3], 0);
                            coin500.Text = realMoneyCount[3].ToString();
                            break;
                        }
                    case "coin100Down":
                        {
                            realMoneyCount[4] = Math.Max(--realMoneyCount[4], 0);
                            coin100.Text = realMoneyCount[4].ToString();
                            break;
                        }
                    case "coin50Down":
                        {
                            realMoneyCount[5] = Math.Max(--realMoneyCount[5], 0);
                            coin50.Text = realMoneyCount[5].ToString();
                            break;
                        }
                    case "coin10Down":
                        {
                            realMoneyCount[6] = Math.Max(--realMoneyCount[6], 0);
                            coin10.Text = realMoneyCount[6].ToString();
                            break;
                        }
                    case "coin5Down":
                        {
                            realMoneyCount[7] = Math.Max(--realMoneyCount[7], 0);
                            coin5.Text = realMoneyCount[7].ToString();
                            break;
                        }
                    case "coin1Down":
                        {
                            realMoneyCount[8] = Math.Max(--realMoneyCount[8], 0);
                            coin1.Text = realMoneyCount[8].ToString();
                            break;
                        }
                }
            }
            pay = realMoney(realMoneyCount, tanka);
            pmnt.Text = pay.ToString();
        }


        private void decision_Click(object sender, EventArgs e)
        {
            int Draw = 0;
            if (decision.Text.Equals("お支払") && basket.Count > 0)
            {
                MenuPanel.Enabled = false;//購入中の商品の取消が出来なくなる
                OrderPanel.Enabled = false;//商品打ち込みが出来なくなる
                emoney.Checked = true;//電子マネー支払モードに入る(これがデフォルト)
                eMoneyPanel.BringToFront();
                cashPanel.Visible = false;
                decision.Text = "確定";
                modoru.Visible = true;
                modoru.Enabled = true;
                DrawerButton.Enabled = false;
            }
            else if (decision.Text.Equals("確定"))
            {
                if (pay >= totalPrice)
                {
                    back.Text = (pay - totalPrice).ToString();
                    basket.Clear();


                    //購入商品リストを消す
                    for (int i = 0; i < textList.GetLength(0); i++)
                    {
                        for (int j = 0; j < textList.GetLength(1); j++)
                        {
                            textList[i,j].Text = "";
                        }
                    }
                    totalPrice = 0;
                    decision.Text = "戻る";
                    Draw = int.Parse(back.Text);
                }
            }
            else if (decision.Text.Equals("戻る"))
            {
                if ((int.Parse(dr1.Text) < 5) || (int.Parse(dr5.Text) < 5) || (int.Parse(dr10.Text) < 5) || (int.Parse(dr50.Text) < 5) || (int.Parse(dr100.Text) < 5) ||
                     (int.Parse(dr500.Text) < 5) || (int.Parse(dr1000.Text) < 5) || (int.Parse(dr5000.Text) < 2))
                {
                    Warning.Visible = true;//警告の文面が出てくる
                    eMoneyPanel.Enabled = false;//電子マネー入力不可
                    cashPanel.Enabled = false;//現金入力不可
                    OrderPanel.Enabled = false;//購入品入力パネル入力不可
                    MenuPanel.Enabled = false;//購入品確認パネル入力不可
                    casher.Enabled = true;//キャッシャーパネル入力不可
                    
                    DrawerPanel.Enabled = true;//ドロワだけ出てきてつり銭補充を迫る
                    DrawerPanel.Visible = true;
                    Warning.BringToFront();
                }

                total.Text = "0";
                subtotal.Text = "0";
                tax.Text = "0";
                pmnt.Text = "0";
                back.Text = "0";
                decision.Text = "お支払";
                totalPrice = 0;
                pay = 0;
                realMoneyCount = new int[9];
                MenuPanel.Enabled = true;
                OrderPanel.Enabled = true;
                DrawerButton.Enabled = true;
                emoney.Checked = true;
            }

            if (cash.Checked)//現金で買った場合のドロワ内
            {
                for (int i = 0; i < realMoneyCount.Length; i++)
                {
                    int n = Draw / tanka[i];//種別ごとにドロワから出ていく数
                    DrawerStock[i] -= n; DrawerStock[i] += realMoneyCount[i];
                    if (i == 0) {dr10000.Text   = DrawerStock[i].ToString(); }
                    if (i == 1) { dr5000.Text   = DrawerStock[i].ToString(); }
                    if (i == 2) { dr1000.Text   = DrawerStock[i].ToString(); }
                    if (i == 3) { dr500.Text    = DrawerStock[i].ToString(); }
                    if (i == 4) { dr100.Text    = DrawerStock[i].ToString(); }
                    if (i == 5) { dr50.Text     = DrawerStock[i].ToString(); }
                    if (i == 6) { dr10.Text     = DrawerStock[i].ToString(); }
                    if (i == 7) { dr5.Text      = DrawerStock[i].ToString(); }
                    if (i == 8) { dr1.Text      = DrawerStock[i].ToString(); }
                    Draw %= tanka[i];
                }
            }
        }

        private void DrawerButton_Click(object sender, EventArgs e)
        {
            if (Warning.Visible)
            {
                DrawerPanel.Visible = true;
                DrawerPanel.BringToFront();
            }
            else if (!DrawerPanel.Visible)
            {
                eMoneyPanel.Enabled = false;
                cashPanel.Enabled = false;
                OrderPanel.Enabled = false;
                MenuPanel.Enabled = false;
                DrawerPanel.Visible = true;
                DrawerPanel.Enabled = true;
                tsuri_supply.Enabled = true;
                casher.Enabled = false;
                DrawerPanel.BringToFront();
                tsuri_supply.BringToFront();
                DrawerButton.Text = "開放中";
            }
        }

        private void modoru_Click(object sender, EventArgs e)
        {
            modoru.Visible = false;
            modoru.Enabled = false;
            casher.Enabled = false;
            eMoneyPanel.Enabled = false;
            cashPanel.Enabled = false;
            MenuPanel.Enabled = true;
            OrderPanel.Enabled = true;
            casher.Enabled = true;
            decision.Text = "お支払";
            cash.Checked = true;
            emoney.Checked = true;
            if(basket.Count == 0)
            {
                DrawerButton.Enabled = true;
            }
        }

        private void tsuri_supply_Click(object sender, EventArgs e)
        {
            DrawerStock = new int[] { 0, 10, 100, 100, 100, 100, 100, 100, 100 };
            dr10000.Text= DrawerStock[0].ToString();
            dr5000.Text = DrawerStock[1].ToString();
            dr1000.Text = DrawerStock[2].ToString();
            dr500.Text  = DrawerStock[3].ToString();
            dr100.Text  = DrawerStock[4].ToString();
            dr50.Text   = DrawerStock[5].ToString();
            dr10.Text   = DrawerStock[6].ToString();
            dr5.Text    = DrawerStock[7].ToString();
            dr1.Text    = DrawerStock[8].ToString();


            if (Warning.Visible)
            {
                Warning.Visible = false;
                OrderPanel.Enabled = true;
                MenuPanel.Enabled = true;
                casher.Enabled = true;
                DrawerPanel.Enabled = false;
                DrawerPanel.Visible = false;
                Warning.SendToBack();
            }
        }

        private void DrawerClose_Click(object sender, EventArgs e)
        {
            DrawerPanel.Visible = false;
            DrawerPanel.Enabled = false;
            tsuri_supply.Enabled = false;
            casher.Enabled= true;
            eMoneyPanel.Enabled = true;
            cashPanel.Enabled = true;
            OrderPanel.Enabled = true;
            MenuPanel.Enabled = true;
            MenuPanel.BringToFront();
            DrawerButton.Text = "ドロワ";
        }
    }
}
