﻿namespace Restaurant
{
    partial class Restaurant
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.cash = new System.Windows.Forms.RadioButton();
            this.emoney = new System.Windows.Forms.RadioButton();
            this.payent = new System.Windows.Forms.GroupBox();
            this.cashPanel = new System.Windows.Forms.Panel();
            this.eMoneyPanel = new System.Windows.Forms.Panel();
            this.modoru = new System.Windows.Forms.Button();
            this.rmv = new System.Windows.Forms.Button();
            this.mn10 = new System.Windows.Forms.Button();
            this.mn0 = new System.Windows.Forms.Button();
            this.mn00 = new System.Windows.Forms.Button();
            this.mn9 = new System.Windows.Forms.Button();
            this.mn8 = new System.Windows.Forms.Button();
            this.mn7 = new System.Windows.Forms.Button();
            this.mn6 = new System.Windows.Forms.Button();
            this.mn5 = new System.Windows.Forms.Button();
            this.mn4 = new System.Windows.Forms.Button();
            this.mn3 = new System.Windows.Forms.Button();
            this.mn2 = new System.Windows.Forms.Button();
            this.mn1 = new System.Windows.Forms.Button();
            this.coin50 = new System.Windows.Forms.TextBox();
            this.coin1Down = new System.Windows.Forms.Button();
            this.coin1Up = new System.Windows.Forms.Button();
            this.label38 = new System.Windows.Forms.Label();
            this.coin1 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.coin5Down = new System.Windows.Forms.Button();
            this.coin5Up = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.coin5 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.coin10Down = new System.Windows.Forms.Button();
            this.coin10Up = new System.Windows.Forms.Button();
            this.label36 = new System.Windows.Forms.Label();
            this.coin10 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.coin50Down = new System.Windows.Forms.Button();
            this.coin50Up = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.coin100Down = new System.Windows.Forms.Button();
            this.coin100Up = new System.Windows.Forms.Button();
            this.label32 = new System.Windows.Forms.Label();
            this.coin100 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.coin500Down = new System.Windows.Forms.Button();
            this.coin500Up = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.coin500 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.sheet1000Down = new System.Windows.Forms.Button();
            this.sheet1000Up = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.sheet1000 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.sheet5000Down = new System.Windows.Forms.Button();
            this.sheet5000Up = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.sheet5000 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.sheet10kDown = new System.Windows.Forms.Button();
            this.sheet10kUp = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.sheet_10k = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.commodity = new System.Windows.Forms.Panel();
            this.Warning = new System.Windows.Forms.Label();
            this.MenuPanel = new System.Windows.Forms.Panel();
            this.DrawerPanel = new System.Windows.Forms.Panel();
            this.DrawerClose = new System.Windows.Forms.Button();
            this.dr10000 = new System.Windows.Forms.TextBox();
            this.dr100 = new System.Windows.Forms.TextBox();
            this.dr500 = new System.Windows.Forms.TextBox();
            this.dr1000 = new System.Windows.Forms.TextBox();
            this.dr5000 = new System.Windows.Forms.TextBox();
            this.dr1 = new System.Windows.Forms.TextBox();
            this.dr5 = new System.Windows.Forms.TextBox();
            this.dr10 = new System.Windows.Forms.TextBox();
            this.dr50 = new System.Windows.Forms.TextBox();
            this.tsuri_supply = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.Drawer10000 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Cancel0 = new System.Windows.Forms.Button();
            this.Line0_3 = new System.Windows.Forms.Label();
            this.Line0_2 = new System.Windows.Forms.Label();
            this.Line0_1 = new System.Windows.Forms.Label();
            this.Line0_0 = new System.Windows.Forms.Label();
            this.Cancel8 = new System.Windows.Forms.Button();
            this.Cancel7 = new System.Windows.Forms.Button();
            this.Cancel6 = new System.Windows.Forms.Button();
            this.Cancel5 = new System.Windows.Forms.Button();
            this.Cancel4 = new System.Windows.Forms.Button();
            this.Cancel2 = new System.Windows.Forms.Button();
            this.Cancel3 = new System.Windows.Forms.Button();
            this.Cancel1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.Line8_3 = new System.Windows.Forms.Label();
            this.Line7_3 = new System.Windows.Forms.Label();
            this.Line6_3 = new System.Windows.Forms.Label();
            this.Line5_3 = new System.Windows.Forms.Label();
            this.Line4_3 = new System.Windows.Forms.Label();
            this.Line3_3 = new System.Windows.Forms.Label();
            this.Line2_3 = new System.Windows.Forms.Label();
            this.Line1_3 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.Line8_2 = new System.Windows.Forms.Label();
            this.Line8_1 = new System.Windows.Forms.Label();
            this.Line8_0 = new System.Windows.Forms.Label();
            this.Line7_2 = new System.Windows.Forms.Label();
            this.Line7_1 = new System.Windows.Forms.Label();
            this.Line7_0 = new System.Windows.Forms.Label();
            this.Line6_2 = new System.Windows.Forms.Label();
            this.Line6_1 = new System.Windows.Forms.Label();
            this.Line6_0 = new System.Windows.Forms.Label();
            this.Line5_2 = new System.Windows.Forms.Label();
            this.Line5_1 = new System.Windows.Forms.Label();
            this.Line5_0 = new System.Windows.Forms.Label();
            this.Line4_2 = new System.Windows.Forms.Label();
            this.Line4_1 = new System.Windows.Forms.Label();
            this.Line4_0 = new System.Windows.Forms.Label();
            this.Line3_2 = new System.Windows.Forms.Label();
            this.Line3_1 = new System.Windows.Forms.Label();
            this.Line3_0 = new System.Windows.Forms.Label();
            this.Line2_2 = new System.Windows.Forms.Label();
            this.Line2_1 = new System.Windows.Forms.Label();
            this.Line2_0 = new System.Windows.Forms.Label();
            this.Line1_2 = new System.Windows.Forms.Label();
            this.Line1_1 = new System.Windows.Forms.Label();
            this.Line1_0 = new System.Windows.Forms.Label();
            this.topic01 = new System.Windows.Forms.Button();
            this.topic02 = new System.Windows.Forms.Button();
            this.topic03 = new System.Windows.Forms.Button();
            this.topic06 = new System.Windows.Forms.Button();
            this.topic05 = new System.Windows.Forms.Button();
            this.topic04 = new System.Windows.Forms.Button();
            this.topic12 = new System.Windows.Forms.Button();
            this.topic11 = new System.Windows.Forms.Button();
            this.topic10 = new System.Windows.Forms.Button();
            this.topic09 = new System.Windows.Forms.Button();
            this.topic08 = new System.Windows.Forms.Button();
            this.topic07 = new System.Windows.Forms.Button();
            this.topic15 = new System.Windows.Forms.Button();
            this.topic14 = new System.Windows.Forms.Button();
            this.topic13 = new System.Windows.Forms.Button();
            this.topic18 = new System.Windows.Forms.Button();
            this.topic17 = new System.Windows.Forms.Button();
            this.topic16 = new System.Windows.Forms.Button();
            this.OrderPanel = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.casher = new System.Windows.Forms.Panel();
            this.DrawerButton = new System.Windows.Forms.Button();
            this.decision = new System.Windows.Forms.Button();
            this.pmnt = new System.Windows.Forms.Label();
            this.ErrorCage = new System.Windows.Forms.Label();
            this.subtotal = new System.Windows.Forms.Label();
            this.tax = new System.Windows.Forms.Label();
            this.back = new System.Windows.Forms.Label();
            this.total = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.payent.SuspendLayout();
            this.cashPanel.SuspendLayout();
            this.eMoneyPanel.SuspendLayout();
            this.commodity.SuspendLayout();
            this.MenuPanel.SuspendLayout();
            this.DrawerPanel.SuspendLayout();
            this.OrderPanel.SuspendLayout();
            this.casher.SuspendLayout();
            this.SuspendLayout();
            // 
            // cash
            // 
            this.cash.AutoSize = true;
            this.cash.Checked = true;
            this.cash.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.cash.Location = new System.Drawing.Point(86, 25);
            this.cash.Name = "cash";
            this.cash.Size = new System.Drawing.Size(72, 26);
            this.cash.TabIndex = 0;
            this.cash.TabStop = true;
            this.cash.Text = "現金";
            this.cash.UseVisualStyleBackColor = true;
            this.cash.CheckedChanged += new System.EventHandler(this.cash_CheckedChanged);
            // 
            // emoney
            // 
            this.emoney.AutoSize = true;
            this.emoney.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.emoney.Location = new System.Drawing.Point(204, 25);
            this.emoney.Name = "emoney";
            this.emoney.Size = new System.Drawing.Size(125, 26);
            this.emoney.TabIndex = 1;
            this.emoney.Text = "電子マネー";
            this.emoney.UseVisualStyleBackColor = true;
            this.emoney.CheckedChanged += new System.EventHandler(this.emoney_CheckedChanged);
            // 
            // payent
            // 
            this.payent.Controls.Add(this.eMoneyPanel);
            this.payent.Controls.Add(this.cash);
            this.payent.Controls.Add(this.emoney);
            this.payent.Controls.Add(this.cashPanel);
            this.payent.Font = new System.Drawing.Font("MS UI Gothic", 24F);
            this.payent.Location = new System.Drawing.Point(505, 4);
            this.payent.Name = "payent";
            this.payent.Size = new System.Drawing.Size(348, 387);
            this.payent.TabIndex = 2;
            this.payent.TabStop = false;
            this.payent.Text = "支払";
            // 
            // cashPanel
            // 
            this.cashPanel.Controls.Add(this.coin50);
            this.cashPanel.Controls.Add(this.coin1Down);
            this.cashPanel.Controls.Add(this.coin1Up);
            this.cashPanel.Controls.Add(this.label38);
            this.cashPanel.Controls.Add(this.coin1);
            this.cashPanel.Controls.Add(this.label39);
            this.cashPanel.Controls.Add(this.coin5Down);
            this.cashPanel.Controls.Add(this.coin5Up);
            this.cashPanel.Controls.Add(this.label34);
            this.cashPanel.Controls.Add(this.coin5);
            this.cashPanel.Controls.Add(this.label35);
            this.cashPanel.Controls.Add(this.coin10Down);
            this.cashPanel.Controls.Add(this.coin10Up);
            this.cashPanel.Controls.Add(this.label36);
            this.cashPanel.Controls.Add(this.coin10);
            this.cashPanel.Controls.Add(this.label37);
            this.cashPanel.Controls.Add(this.coin50Down);
            this.cashPanel.Controls.Add(this.coin50Up);
            this.cashPanel.Controls.Add(this.label23);
            this.cashPanel.Controls.Add(this.label24);
            this.cashPanel.Controls.Add(this.coin100Down);
            this.cashPanel.Controls.Add(this.coin100Up);
            this.cashPanel.Controls.Add(this.label32);
            this.cashPanel.Controls.Add(this.coin100);
            this.cashPanel.Controls.Add(this.label33);
            this.cashPanel.Controls.Add(this.coin500Down);
            this.cashPanel.Controls.Add(this.coin500Up);
            this.cashPanel.Controls.Add(this.label15);
            this.cashPanel.Controls.Add(this.coin500);
            this.cashPanel.Controls.Add(this.label18);
            this.cashPanel.Controls.Add(this.sheet1000Down);
            this.cashPanel.Controls.Add(this.sheet1000Up);
            this.cashPanel.Controls.Add(this.label21);
            this.cashPanel.Controls.Add(this.sheet1000);
            this.cashPanel.Controls.Add(this.label22);
            this.cashPanel.Controls.Add(this.sheet5000Down);
            this.cashPanel.Controls.Add(this.sheet5000Up);
            this.cashPanel.Controls.Add(this.label11);
            this.cashPanel.Controls.Add(this.sheet5000);
            this.cashPanel.Controls.Add(this.label12);
            this.cashPanel.Controls.Add(this.sheet10kDown);
            this.cashPanel.Controls.Add(this.sheet10kUp);
            this.cashPanel.Controls.Add(this.label10);
            this.cashPanel.Controls.Add(this.sheet_10k);
            this.cashPanel.Controls.Add(this.label9);
            this.cashPanel.Enabled = false;
            this.cashPanel.Location = new System.Drawing.Point(6, 56);
            this.cashPanel.Name = "cashPanel";
            this.cashPanel.Size = new System.Drawing.Size(342, 328);
            this.cashPanel.TabIndex = 4;
            this.cashPanel.Visible = false;
            // 
            // eMoneyPanel
            // 
            this.eMoneyPanel.Controls.Add(this.modoru);
            this.eMoneyPanel.Controls.Add(this.rmv);
            this.eMoneyPanel.Controls.Add(this.mn10);
            this.eMoneyPanel.Controls.Add(this.mn0);
            this.eMoneyPanel.Controls.Add(this.mn00);
            this.eMoneyPanel.Controls.Add(this.mn9);
            this.eMoneyPanel.Controls.Add(this.mn8);
            this.eMoneyPanel.Controls.Add(this.mn7);
            this.eMoneyPanel.Controls.Add(this.mn6);
            this.eMoneyPanel.Controls.Add(this.mn5);
            this.eMoneyPanel.Controls.Add(this.mn4);
            this.eMoneyPanel.Controls.Add(this.mn3);
            this.eMoneyPanel.Controls.Add(this.mn2);
            this.eMoneyPanel.Controls.Add(this.mn1);
            this.eMoneyPanel.Enabled = false;
            this.eMoneyPanel.Location = new System.Drawing.Point(0, 56);
            this.eMoneyPanel.Name = "eMoneyPanel";
            this.eMoneyPanel.Size = new System.Drawing.Size(348, 333);
            this.eMoneyPanel.TabIndex = 23;
            // 
            // modoru
            // 
            this.modoru.Enabled = false;
            this.modoru.Font = new System.Drawing.Font("MS UI Gothic", 18F);
            this.modoru.Location = new System.Drawing.Point(249, 88);
            this.modoru.Name = "modoru";
            this.modoru.Size = new System.Drawing.Size(72, 142);
            this.modoru.TabIndex = 25;
            this.modoru.Text = "戻  る";
            this.modoru.UseVisualStyleBackColor = true;
            this.modoru.Visible = false;
            this.modoru.Click += new System.EventHandler(this.modoru_Click);
            // 
            // rmv
            // 
            this.rmv.Font = new System.Drawing.Font("MS UI Gothic", 18F);
            this.rmv.Location = new System.Drawing.Point(247, 235);
            this.rmv.Name = "rmv";
            this.rmv.Size = new System.Drawing.Size(75, 68);
            this.rmv.TabIndex = 24;
            this.rmv.Text = "取消";
            this.rmv.UseVisualStyleBackColor = true;
            this.rmv.Click += new System.EventHandler(this.rmv_Click);
            // 
            // mn10
            // 
            this.mn10.Font = new System.Drawing.Font("MS UI Gothic", 18F);
            this.mn10.Location = new System.Drawing.Point(171, 235);
            this.mn10.Name = "mn10";
            this.mn10.Size = new System.Drawing.Size(72, 68);
            this.mn10.TabIndex = 24;
            this.mn10.Text = "万円";
            this.mn10.UseVisualStyleBackColor = true;
            this.mn10.Click += new System.EventHandler(this.mn10_Click);
            // 
            // mn0
            // 
            this.mn0.Font = new System.Drawing.Font("MS UI Gothic", 24F);
            this.mn0.Location = new System.Drawing.Point(93, 235);
            this.mn0.Name = "mn0";
            this.mn0.Size = new System.Drawing.Size(72, 68);
            this.mn0.TabIndex = 9;
            this.mn0.Text = "0";
            this.mn0.UseVisualStyleBackColor = true;
            this.mn0.Click += new System.EventHandler(this.mn0_Click);
            // 
            // mn00
            // 
            this.mn00.Font = new System.Drawing.Font("MS UI Gothic", 24F);
            this.mn00.Location = new System.Drawing.Point(15, 235);
            this.mn00.Name = "mn00";
            this.mn00.Size = new System.Drawing.Size(72, 68);
            this.mn00.TabIndex = 23;
            this.mn00.Text = "00";
            this.mn00.UseVisualStyleBackColor = true;
            this.mn00.Click += new System.EventHandler(this.mn00_Click);
            // 
            // mn9
            // 
            this.mn9.Font = new System.Drawing.Font("MS UI Gothic", 24F);
            this.mn9.Location = new System.Drawing.Point(171, 161);
            this.mn9.Name = "mn9";
            this.mn9.Size = new System.Drawing.Size(72, 68);
            this.mn9.TabIndex = 8;
            this.mn9.Text = "9";
            this.mn9.UseVisualStyleBackColor = true;
            this.mn9.Click += new System.EventHandler(this.mn9_Click);
            // 
            // mn8
            // 
            this.mn8.Font = new System.Drawing.Font("MS UI Gothic", 24F);
            this.mn8.Location = new System.Drawing.Point(93, 161);
            this.mn8.Name = "mn8";
            this.mn8.Size = new System.Drawing.Size(72, 68);
            this.mn8.TabIndex = 7;
            this.mn8.Text = "8";
            this.mn8.UseVisualStyleBackColor = true;
            this.mn8.Click += new System.EventHandler(this.mn8_Click);
            // 
            // mn7
            // 
            this.mn7.Font = new System.Drawing.Font("MS UI Gothic", 24F);
            this.mn7.Location = new System.Drawing.Point(15, 161);
            this.mn7.Name = "mn7";
            this.mn7.Size = new System.Drawing.Size(72, 68);
            this.mn7.TabIndex = 6;
            this.mn7.Text = "7";
            this.mn7.UseVisualStyleBackColor = true;
            this.mn7.Click += new System.EventHandler(this.mn7_Click);
            // 
            // mn6
            // 
            this.mn6.Font = new System.Drawing.Font("MS UI Gothic", 24F);
            this.mn6.Location = new System.Drawing.Point(171, 87);
            this.mn6.Name = "mn6";
            this.mn6.Size = new System.Drawing.Size(72, 68);
            this.mn6.TabIndex = 5;
            this.mn6.Text = "6";
            this.mn6.UseVisualStyleBackColor = true;
            this.mn6.Click += new System.EventHandler(this.mn6_Click);
            // 
            // mn5
            // 
            this.mn5.Font = new System.Drawing.Font("MS UI Gothic", 24F);
            this.mn5.Location = new System.Drawing.Point(93, 87);
            this.mn5.Name = "mn5";
            this.mn5.Size = new System.Drawing.Size(72, 68);
            this.mn5.TabIndex = 4;
            this.mn5.Text = "5";
            this.mn5.UseVisualStyleBackColor = true;
            this.mn5.Click += new System.EventHandler(this.mn5_Click);
            // 
            // mn4
            // 
            this.mn4.Font = new System.Drawing.Font("MS UI Gothic", 24F);
            this.mn4.Location = new System.Drawing.Point(15, 87);
            this.mn4.Name = "mn4";
            this.mn4.Size = new System.Drawing.Size(72, 68);
            this.mn4.TabIndex = 3;
            this.mn4.Text = "4";
            this.mn4.UseVisualStyleBackColor = true;
            this.mn4.Click += new System.EventHandler(this.mn4_Click);
            // 
            // mn3
            // 
            this.mn3.Font = new System.Drawing.Font("MS UI Gothic", 24F);
            this.mn3.Location = new System.Drawing.Point(171, 13);
            this.mn3.Name = "mn3";
            this.mn3.Size = new System.Drawing.Size(72, 68);
            this.mn3.TabIndex = 2;
            this.mn3.Text = "3";
            this.mn3.UseVisualStyleBackColor = true;
            this.mn3.Click += new System.EventHandler(this.mn3_Click);
            // 
            // mn2
            // 
            this.mn2.Font = new System.Drawing.Font("MS UI Gothic", 24F);
            this.mn2.Location = new System.Drawing.Point(93, 13);
            this.mn2.Name = "mn2";
            this.mn2.Size = new System.Drawing.Size(72, 68);
            this.mn2.TabIndex = 1;
            this.mn2.Text = "2";
            this.mn2.UseVisualStyleBackColor = true;
            this.mn2.Click += new System.EventHandler(this.mn2_Click);
            // 
            // mn1
            // 
            this.mn1.Font = new System.Drawing.Font("MS UI Gothic", 24F);
            this.mn1.Location = new System.Drawing.Point(15, 13);
            this.mn1.Name = "mn1";
            this.mn1.Size = new System.Drawing.Size(72, 68);
            this.mn1.TabIndex = 0;
            this.mn1.Text = "1";
            this.mn1.UseVisualStyleBackColor = true;
            this.mn1.Click += new System.EventHandler(this.mn1_Click);
            // 
            // coin50
            // 
            this.coin50.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.coin50.Location = new System.Drawing.Point(100, 193);
            this.coin50.Name = "coin50";
            this.coin50.Size = new System.Drawing.Size(52, 29);
            this.coin50.TabIndex = 82;
            this.coin50.Text = "0";
            this.coin50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // coin1Down
            // 
            this.coin1Down.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.coin1Down.Location = new System.Drawing.Point(260, 296);
            this.coin1Down.Name = "coin1Down";
            this.coin1Down.Size = new System.Drawing.Size(43, 31);
            this.coin1Down.TabIndex = 81;
            this.coin1Down.Text = "-";
            this.coin1Down.UseVisualStyleBackColor = true;
            this.coin1Down.Click += new System.EventHandler(this.Down_Click);
            // 
            // coin1Up
            // 
            this.coin1Up.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.coin1Up.Location = new System.Drawing.Point(211, 296);
            this.coin1Up.Name = "coin1Up";
            this.coin1Up.Size = new System.Drawing.Size(43, 31);
            this.coin1Up.TabIndex = 80;
            this.coin1Up.Text = "+";
            this.coin1Up.UseVisualStyleBackColor = true;
            this.coin1Up.Click += new System.EventHandler(this.Up_Click);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label38.Location = new System.Drawing.Point(158, 300);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(32, 22);
            this.label38.TabIndex = 79;
            this.label38.Text = "枚";
            // 
            // coin1
            // 
            this.coin1.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.coin1.Location = new System.Drawing.Point(100, 296);
            this.coin1.Name = "coin1";
            this.coin1.Size = new System.Drawing.Size(52, 29);
            this.coin1.TabIndex = 78;
            this.coin1.Text = "0";
            this.coin1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.coin1.TextChanged += new System.EventHandler(this.coin1_TextChanged);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label39.Location = new System.Drawing.Point(40, 300);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(54, 22);
            this.label39.TabIndex = 77;
            this.label39.Text = "1円：";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // coin5Down
            // 
            this.coin5Down.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.coin5Down.Location = new System.Drawing.Point(260, 262);
            this.coin5Down.Name = "coin5Down";
            this.coin5Down.Size = new System.Drawing.Size(43, 31);
            this.coin5Down.TabIndex = 76;
            this.coin5Down.Text = "-";
            this.coin5Down.UseVisualStyleBackColor = true;
            this.coin5Down.Click += new System.EventHandler(this.Down_Click);
            // 
            // coin5Up
            // 
            this.coin5Up.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.coin5Up.Location = new System.Drawing.Point(211, 262);
            this.coin5Up.Name = "coin5Up";
            this.coin5Up.Size = new System.Drawing.Size(43, 31);
            this.coin5Up.TabIndex = 75;
            this.coin5Up.Text = "+";
            this.coin5Up.UseVisualStyleBackColor = true;
            this.coin5Up.Click += new System.EventHandler(this.Up_Click);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label34.Location = new System.Drawing.Point(158, 266);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(32, 22);
            this.label34.TabIndex = 74;
            this.label34.Text = "枚";
            // 
            // coin5
            // 
            this.coin5.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.coin5.Location = new System.Drawing.Point(100, 262);
            this.coin5.Name = "coin5";
            this.coin5.Size = new System.Drawing.Size(52, 29);
            this.coin5.TabIndex = 73;
            this.coin5.Text = "0";
            this.coin5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.coin5.TextChanged += new System.EventHandler(this.coin5_TextChanged);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label35.Location = new System.Drawing.Point(40, 266);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(54, 22);
            this.label35.TabIndex = 72;
            this.label35.Text = "5円：";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // coin10Down
            // 
            this.coin10Down.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.coin10Down.Location = new System.Drawing.Point(260, 227);
            this.coin10Down.Name = "coin10Down";
            this.coin10Down.Size = new System.Drawing.Size(43, 31);
            this.coin10Down.TabIndex = 71;
            this.coin10Down.Text = "-";
            this.coin10Down.UseVisualStyleBackColor = true;
            this.coin10Down.Click += new System.EventHandler(this.Down_Click);
            // 
            // coin10Up
            // 
            this.coin10Up.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.coin10Up.Location = new System.Drawing.Point(211, 226);
            this.coin10Up.Name = "coin10Up";
            this.coin10Up.Size = new System.Drawing.Size(43, 31);
            this.coin10Up.TabIndex = 70;
            this.coin10Up.Text = "+";
            this.coin10Up.UseVisualStyleBackColor = true;
            this.coin10Up.Click += new System.EventHandler(this.Up_Click);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label36.Location = new System.Drawing.Point(158, 231);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(32, 22);
            this.label36.TabIndex = 69;
            this.label36.Text = "枚";
            // 
            // coin10
            // 
            this.coin10.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.coin10.Location = new System.Drawing.Point(100, 227);
            this.coin10.Name = "coin10";
            this.coin10.Size = new System.Drawing.Size(52, 29);
            this.coin10.TabIndex = 68;
            this.coin10.Text = "0";
            this.coin10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.coin10.TextChanged += new System.EventHandler(this.coin10_TextChanged);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label37.Location = new System.Drawing.Point(29, 231);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(65, 22);
            this.label37.TabIndex = 67;
            this.label37.Text = "10円：";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // coin50Down
            // 
            this.coin50Down.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.coin50Down.Location = new System.Drawing.Point(260, 192);
            this.coin50Down.Name = "coin50Down";
            this.coin50Down.Size = new System.Drawing.Size(43, 31);
            this.coin50Down.TabIndex = 66;
            this.coin50Down.Text = "-";
            this.coin50Down.UseVisualStyleBackColor = true;
            this.coin50Down.Click += new System.EventHandler(this.Down_Click);
            // 
            // coin50Up
            // 
            this.coin50Up.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.coin50Up.Location = new System.Drawing.Point(211, 192);
            this.coin50Up.Name = "coin50Up";
            this.coin50Up.Size = new System.Drawing.Size(43, 31);
            this.coin50Up.TabIndex = 65;
            this.coin50Up.Text = "+";
            this.coin50Up.UseVisualStyleBackColor = true;
            this.coin50Up.Click += new System.EventHandler(this.Up_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label23.Location = new System.Drawing.Point(158, 196);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(32, 22);
            this.label23.TabIndex = 64;
            this.label23.Text = "枚";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label24.Location = new System.Drawing.Point(29, 196);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(65, 22);
            this.label24.TabIndex = 62;
            this.label24.Text = "50円：";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // coin100Down
            // 
            this.coin100Down.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.coin100Down.Location = new System.Drawing.Point(260, 157);
            this.coin100Down.Name = "coin100Down";
            this.coin100Down.Size = new System.Drawing.Size(43, 31);
            this.coin100Down.TabIndex = 61;
            this.coin100Down.Text = "-";
            this.coin100Down.UseVisualStyleBackColor = true;
            this.coin100Down.Click += new System.EventHandler(this.Down_Click);
            // 
            // coin100Up
            // 
            this.coin100Up.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.coin100Up.Location = new System.Drawing.Point(211, 156);
            this.coin100Up.Name = "coin100Up";
            this.coin100Up.Size = new System.Drawing.Size(43, 31);
            this.coin100Up.TabIndex = 60;
            this.coin100Up.Text = "+";
            this.coin100Up.UseVisualStyleBackColor = true;
            this.coin100Up.Click += new System.EventHandler(this.Up_Click);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label32.Location = new System.Drawing.Point(158, 161);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(32, 22);
            this.label32.TabIndex = 59;
            this.label32.Text = "枚";
            // 
            // coin100
            // 
            this.coin100.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.coin100.Location = new System.Drawing.Point(100, 157);
            this.coin100.Name = "coin100";
            this.coin100.Size = new System.Drawing.Size(52, 29);
            this.coin100.TabIndex = 58;
            this.coin100.Text = "0";
            this.coin100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.coin100.TextChanged += new System.EventHandler(this.coin100_TextChanged);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label33.Location = new System.Drawing.Point(18, 161);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(76, 22);
            this.label33.TabIndex = 57;
            this.label33.Text = "100円：";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // coin500Down
            // 
            this.coin500Down.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.coin500Down.Location = new System.Drawing.Point(260, 122);
            this.coin500Down.Name = "coin500Down";
            this.coin500Down.Size = new System.Drawing.Size(43, 31);
            this.coin500Down.TabIndex = 56;
            this.coin500Down.Text = "-";
            this.coin500Down.UseVisualStyleBackColor = true;
            this.coin500Down.Click += new System.EventHandler(this.Down_Click);
            // 
            // coin500Up
            // 
            this.coin500Up.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.coin500Up.Location = new System.Drawing.Point(211, 122);
            this.coin500Up.Name = "coin500Up";
            this.coin500Up.Size = new System.Drawing.Size(43, 31);
            this.coin500Up.TabIndex = 55;
            this.coin500Up.Text = "+";
            this.coin500Up.UseVisualStyleBackColor = true;
            this.coin500Up.Click += new System.EventHandler(this.Up_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label15.Location = new System.Drawing.Point(158, 126);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(32, 22);
            this.label15.TabIndex = 54;
            this.label15.Text = "枚";
            // 
            // coin500
            // 
            this.coin500.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.coin500.Location = new System.Drawing.Point(100, 122);
            this.coin500.Name = "coin500";
            this.coin500.Size = new System.Drawing.Size(52, 29);
            this.coin500.TabIndex = 53;
            this.coin500.Text = "0";
            this.coin500.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.coin500.TextChanged += new System.EventHandler(this.coin500_TextChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label18.Location = new System.Drawing.Point(18, 126);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(76, 22);
            this.label18.TabIndex = 52;
            this.label18.Text = "500円：";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // sheet1000Down
            // 
            this.sheet1000Down.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.sheet1000Down.Location = new System.Drawing.Point(260, 87);
            this.sheet1000Down.Name = "sheet1000Down";
            this.sheet1000Down.Size = new System.Drawing.Size(43, 31);
            this.sheet1000Down.TabIndex = 51;
            this.sheet1000Down.Text = "-";
            this.sheet1000Down.UseVisualStyleBackColor = true;
            this.sheet1000Down.Click += new System.EventHandler(this.Down_Click);
            // 
            // sheet1000Up
            // 
            this.sheet1000Up.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.sheet1000Up.Location = new System.Drawing.Point(211, 86);
            this.sheet1000Up.Name = "sheet1000Up";
            this.sheet1000Up.Size = new System.Drawing.Size(43, 31);
            this.sheet1000Up.TabIndex = 50;
            this.sheet1000Up.Text = "+";
            this.sheet1000Up.UseVisualStyleBackColor = true;
            this.sheet1000Up.Click += new System.EventHandler(this.Up_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label21.Location = new System.Drawing.Point(158, 91);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(32, 22);
            this.label21.TabIndex = 49;
            this.label21.Text = "枚";
            // 
            // sheet1000
            // 
            this.sheet1000.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.sheet1000.Location = new System.Drawing.Point(100, 87);
            this.sheet1000.Name = "sheet1000";
            this.sheet1000.Size = new System.Drawing.Size(52, 29);
            this.sheet1000.TabIndex = 48;
            this.sheet1000.Text = "0";
            this.sheet1000.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.sheet1000.TextChanged += new System.EventHandler(this.sheet1000_TextChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label22.Location = new System.Drawing.Point(7, 92);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(87, 22);
            this.label22.TabIndex = 47;
            this.label22.Text = "1000円：";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // sheet5000Down
            // 
            this.sheet5000Down.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.sheet5000Down.Location = new System.Drawing.Point(260, 48);
            this.sheet5000Down.Name = "sheet5000Down";
            this.sheet5000Down.Size = new System.Drawing.Size(43, 31);
            this.sheet5000Down.TabIndex = 46;
            this.sheet5000Down.Text = "-";
            this.sheet5000Down.UseVisualStyleBackColor = true;
            this.sheet5000Down.Click += new System.EventHandler(this.Down_Click);
            // 
            // sheet5000Up
            // 
            this.sheet5000Up.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.sheet5000Up.Location = new System.Drawing.Point(211, 48);
            this.sheet5000Up.Name = "sheet5000Up";
            this.sheet5000Up.Size = new System.Drawing.Size(43, 31);
            this.sheet5000Up.TabIndex = 45;
            this.sheet5000Up.Text = "+";
            this.sheet5000Up.UseVisualStyleBackColor = true;
            this.sheet5000Up.Click += new System.EventHandler(this.Up_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label11.Location = new System.Drawing.Point(158, 52);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(32, 22);
            this.label11.TabIndex = 44;
            this.label11.Text = "枚";
            // 
            // sheet5000
            // 
            this.sheet5000.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.sheet5000.Location = new System.Drawing.Point(100, 48);
            this.sheet5000.Name = "sheet5000";
            this.sheet5000.Size = new System.Drawing.Size(52, 29);
            this.sheet5000.TabIndex = 43;
            this.sheet5000.Text = "0";
            this.sheet5000.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.sheet5000.TextChanged += new System.EventHandler(this.sheet5000_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label12.Location = new System.Drawing.Point(7, 52);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(87, 22);
            this.label12.TabIndex = 42;
            this.label12.Text = "5000円：";
            // 
            // sheet10kDown
            // 
            this.sheet10kDown.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.sheet10kDown.Location = new System.Drawing.Point(260, 13);
            this.sheet10kDown.Name = "sheet10kDown";
            this.sheet10kDown.Size = new System.Drawing.Size(43, 31);
            this.sheet10kDown.TabIndex = 41;
            this.sheet10kDown.Text = "-";
            this.sheet10kDown.UseVisualStyleBackColor = true;
            this.sheet10kDown.Click += new System.EventHandler(this.Down_Click);
            // 
            // sheet10kUp
            // 
            this.sheet10kUp.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.sheet10kUp.Location = new System.Drawing.Point(211, 12);
            this.sheet10kUp.Name = "sheet10kUp";
            this.sheet10kUp.Size = new System.Drawing.Size(43, 31);
            this.sheet10kUp.TabIndex = 40;
            this.sheet10kUp.Text = "+";
            this.sheet10kUp.UseVisualStyleBackColor = true;
            this.sheet10kUp.Click += new System.EventHandler(this.Up_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label10.Location = new System.Drawing.Point(158, 17);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(32, 22);
            this.label10.TabIndex = 39;
            this.label10.Text = "枚";
            // 
            // sheet_10k
            // 
            this.sheet_10k.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.sheet_10k.Location = new System.Drawing.Point(100, 13);
            this.sheet_10k.Name = "sheet_10k";
            this.sheet_10k.Size = new System.Drawing.Size(52, 29);
            this.sheet_10k.TabIndex = 38;
            this.sheet_10k.Text = "0";
            this.sheet_10k.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.sheet_10k.TextChanged += new System.EventHandler(this.sheet_10k_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label9.Location = new System.Drawing.Point(18, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 22);
            this.label9.TabIndex = 37;
            this.label9.Text = "1万円：";
            // 
            // commodity
            // 
            this.commodity.BackColor = System.Drawing.Color.Tan;
            this.commodity.Controls.Add(this.Warning);
            this.commodity.Controls.Add(this.MenuPanel);
            this.commodity.Location = new System.Drawing.Point(13, 13);
            this.commodity.Name = "commodity";
            this.commodity.Size = new System.Drawing.Size(486, 363);
            this.commodity.TabIndex = 3;
            // 
            // Warning
            // 
            this.Warning.AutoSize = true;
            this.Warning.BackColor = System.Drawing.Color.Red;
            this.Warning.Font = new System.Drawing.Font("MS UI Gothic", 30F);
            this.Warning.Location = new System.Drawing.Point(-7, 347);
            this.Warning.Name = "Warning";
            this.Warning.Size = new System.Drawing.Size(772, 40);
            this.Warning.TabIndex = 29;
            this.Warning.Text = "ドロワを開き釣り銭を確認の上、補充してください";
            this.Warning.Visible = false;
            // 
            // MenuPanel
            // 
            this.MenuPanel.BackColor = System.Drawing.Color.White;
            this.MenuPanel.Controls.Add(this.DrawerPanel);
            this.MenuPanel.Controls.Add(this.Cancel0);
            this.MenuPanel.Controls.Add(this.Line0_3);
            this.MenuPanel.Controls.Add(this.Line0_2);
            this.MenuPanel.Controls.Add(this.Line0_1);
            this.MenuPanel.Controls.Add(this.Line0_0);
            this.MenuPanel.Controls.Add(this.Cancel8);
            this.MenuPanel.Controls.Add(this.Cancel7);
            this.MenuPanel.Controls.Add(this.Cancel6);
            this.MenuPanel.Controls.Add(this.Cancel5);
            this.MenuPanel.Controls.Add(this.Cancel4);
            this.MenuPanel.Controls.Add(this.Cancel2);
            this.MenuPanel.Controls.Add(this.Cancel3);
            this.MenuPanel.Controls.Add(this.Cancel1);
            this.MenuPanel.Controls.Add(this.label1);
            this.MenuPanel.Controls.Add(this.label28);
            this.MenuPanel.Controls.Add(this.Line8_3);
            this.MenuPanel.Controls.Add(this.Line7_3);
            this.MenuPanel.Controls.Add(this.Line6_3);
            this.MenuPanel.Controls.Add(this.Line5_3);
            this.MenuPanel.Controls.Add(this.Line4_3);
            this.MenuPanel.Controls.Add(this.Line3_3);
            this.MenuPanel.Controls.Add(this.Line2_3);
            this.MenuPanel.Controls.Add(this.Line1_3);
            this.MenuPanel.Controls.Add(this.label27);
            this.MenuPanel.Controls.Add(this.label26);
            this.MenuPanel.Controls.Add(this.label25);
            this.MenuPanel.Controls.Add(this.Line8_2);
            this.MenuPanel.Controls.Add(this.Line8_1);
            this.MenuPanel.Controls.Add(this.Line8_0);
            this.MenuPanel.Controls.Add(this.Line7_2);
            this.MenuPanel.Controls.Add(this.Line7_1);
            this.MenuPanel.Controls.Add(this.Line7_0);
            this.MenuPanel.Controls.Add(this.Line6_2);
            this.MenuPanel.Controls.Add(this.Line6_1);
            this.MenuPanel.Controls.Add(this.Line6_0);
            this.MenuPanel.Controls.Add(this.Line5_2);
            this.MenuPanel.Controls.Add(this.Line5_1);
            this.MenuPanel.Controls.Add(this.Line5_0);
            this.MenuPanel.Controls.Add(this.Line4_2);
            this.MenuPanel.Controls.Add(this.Line4_1);
            this.MenuPanel.Controls.Add(this.Line4_0);
            this.MenuPanel.Controls.Add(this.Line3_2);
            this.MenuPanel.Controls.Add(this.Line3_1);
            this.MenuPanel.Controls.Add(this.Line3_0);
            this.MenuPanel.Controls.Add(this.Line2_2);
            this.MenuPanel.Controls.Add(this.Line2_1);
            this.MenuPanel.Controls.Add(this.Line2_0);
            this.MenuPanel.Controls.Add(this.Line1_2);
            this.MenuPanel.Controls.Add(this.Line1_1);
            this.MenuPanel.Controls.Add(this.Line1_0);
            this.MenuPanel.Location = new System.Drawing.Point(7, 25);
            this.MenuPanel.Name = "MenuPanel";
            this.MenuPanel.Size = new System.Drawing.Size(476, 325);
            this.MenuPanel.TabIndex = 2;
            // 
            // DrawerPanel
            // 
            this.DrawerPanel.BackColor = System.Drawing.Color.Snow;
            this.DrawerPanel.Controls.Add(this.DrawerClose);
            this.DrawerPanel.Controls.Add(this.dr10000);
            this.DrawerPanel.Controls.Add(this.dr100);
            this.DrawerPanel.Controls.Add(this.dr500);
            this.DrawerPanel.Controls.Add(this.dr1000);
            this.DrawerPanel.Controls.Add(this.dr5000);
            this.DrawerPanel.Controls.Add(this.dr1);
            this.DrawerPanel.Controls.Add(this.dr5);
            this.DrawerPanel.Controls.Add(this.dr10);
            this.DrawerPanel.Controls.Add(this.dr50);
            this.DrawerPanel.Controls.Add(this.tsuri_supply);
            this.DrawerPanel.Controls.Add(this.label19);
            this.DrawerPanel.Controls.Add(this.label20);
            this.DrawerPanel.Controls.Add(this.label29);
            this.DrawerPanel.Controls.Add(this.label30);
            this.DrawerPanel.Controls.Add(this.label17);
            this.DrawerPanel.Controls.Add(this.label14);
            this.DrawerPanel.Controls.Add(this.label16);
            this.DrawerPanel.Controls.Add(this.label13);
            this.DrawerPanel.Controls.Add(this.Drawer10000);
            this.DrawerPanel.Controls.Add(this.label8);
            this.DrawerPanel.Enabled = false;
            this.DrawerPanel.Location = new System.Drawing.Point(0, 0);
            this.DrawerPanel.Name = "DrawerPanel";
            this.DrawerPanel.Size = new System.Drawing.Size(475, 325);
            this.DrawerPanel.TabIndex = 29;
            this.DrawerPanel.Visible = false;
            // 
            // DrawerClose
            // 
            this.DrawerClose.Font = new System.Drawing.Font("MS UI Gothic", 18F);
            this.DrawerClose.Location = new System.Drawing.Point(361, 170);
            this.DrawerClose.Name = "DrawerClose";
            this.DrawerClose.Size = new System.Drawing.Size(99, 70);
            this.DrawerClose.TabIndex = 29;
            this.DrawerClose.Text = "ドロワ  クローズ";
            this.DrawerClose.UseVisualStyleBackColor = true;
            this.DrawerClose.Click += new System.EventHandler(this.DrawerClose_Click);
            // 
            // dr10000
            // 
            this.dr10000.Font = new System.Drawing.Font("MS UI Gothic", 22F);
            this.dr10000.Location = new System.Drawing.Point(108, 40);
            this.dr10000.Name = "dr10000";
            this.dr10000.Size = new System.Drawing.Size(62, 37);
            this.dr10000.TabIndex = 28;
            this.dr10000.Text = "0";
            // 
            // dr100
            // 
            this.dr100.Font = new System.Drawing.Font("MS UI Gothic", 22F);
            this.dr100.Location = new System.Drawing.Point(108, 251);
            this.dr100.Name = "dr100";
            this.dr100.Size = new System.Drawing.Size(62, 37);
            this.dr100.TabIndex = 27;
            this.dr100.Text = "100";
            // 
            // dr500
            // 
            this.dr500.Font = new System.Drawing.Font("MS UI Gothic", 22F);
            this.dr500.Location = new System.Drawing.Point(108, 196);
            this.dr500.Name = "dr500";
            this.dr500.Size = new System.Drawing.Size(62, 37);
            this.dr500.TabIndex = 26;
            this.dr500.Text = "100";
            // 
            // dr1000
            // 
            this.dr1000.Font = new System.Drawing.Font("MS UI Gothic", 22F);
            this.dr1000.Location = new System.Drawing.Point(108, 145);
            this.dr1000.Name = "dr1000";
            this.dr1000.Size = new System.Drawing.Size(62, 37);
            this.dr1000.TabIndex = 25;
            this.dr1000.Text = "100";
            // 
            // dr5000
            // 
            this.dr5000.Font = new System.Drawing.Font("MS UI Gothic", 22F);
            this.dr5000.Location = new System.Drawing.Point(108, 92);
            this.dr5000.Name = "dr5000";
            this.dr5000.Size = new System.Drawing.Size(62, 37);
            this.dr5000.TabIndex = 24;
            this.dr5000.Text = "20";
            // 
            // dr1
            // 
            this.dr1.Font = new System.Drawing.Font("MS UI Gothic", 22F);
            this.dr1.Location = new System.Drawing.Point(293, 197);
            this.dr1.Name = "dr1";
            this.dr1.Size = new System.Drawing.Size(62, 37);
            this.dr1.TabIndex = 23;
            this.dr1.Text = "100";
            // 
            // dr5
            // 
            this.dr5.Font = new System.Drawing.Font("MS UI Gothic", 22F);
            this.dr5.Location = new System.Drawing.Point(293, 145);
            this.dr5.Name = "dr5";
            this.dr5.Size = new System.Drawing.Size(62, 37);
            this.dr5.TabIndex = 22;
            this.dr5.Text = "100";
            // 
            // dr10
            // 
            this.dr10.Font = new System.Drawing.Font("MS UI Gothic", 22F);
            this.dr10.Location = new System.Drawing.Point(293, 91);
            this.dr10.Name = "dr10";
            this.dr10.Size = new System.Drawing.Size(62, 37);
            this.dr10.TabIndex = 21;
            this.dr10.Text = "100";
            // 
            // dr50
            // 
            this.dr50.Font = new System.Drawing.Font("MS UI Gothic", 22F);
            this.dr50.Location = new System.Drawing.Point(293, 40);
            this.dr50.Name = "dr50";
            this.dr50.Size = new System.Drawing.Size(62, 37);
            this.dr50.TabIndex = 20;
            this.dr50.Text = "100";
            // 
            // tsuri_supply
            // 
            this.tsuri_supply.BackColor = System.Drawing.Color.Moccasin;
            this.tsuri_supply.Font = new System.Drawing.Font("MS UI Gothic", 22F);
            this.tsuri_supply.Location = new System.Drawing.Point(226, 248);
            this.tsuri_supply.Name = "tsuri_supply";
            this.tsuri_supply.Size = new System.Drawing.Size(206, 62);
            this.tsuri_supply.TabIndex = 19;
            this.tsuri_supply.Text = "釣り銭補充";
            this.tsuri_supply.UseVisualStyleBackColor = false;
            this.tsuri_supply.Click += new System.EventHandler(this.tsuri_supply_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("MS UI Gothic", 12F);
            this.label19.Location = new System.Drawing.Point(223, 211);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(39, 16);
            this.label19.TabIndex = 9;
            this.label19.Text = "1円：";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("MS UI Gothic", 12F);
            this.label20.Location = new System.Drawing.Point(223, 160);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(39, 16);
            this.label20.TabIndex = 8;
            this.label20.Text = "5円：";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("MS UI Gothic", 12F);
            this.label29.Location = new System.Drawing.Point(215, 105);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(47, 16);
            this.label29.TabIndex = 7;
            this.label29.Text = "10円：";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("MS UI Gothic", 12F);
            this.label30.Location = new System.Drawing.Point(215, 54);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(47, 16);
            this.label30.TabIndex = 6;
            this.label30.Text = "50円：";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("MS UI Gothic", 12F);
            this.label17.Location = new System.Drawing.Point(34, 265);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 16);
            this.label17.TabIndex = 5;
            this.label17.Text = "100円：";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("MS UI Gothic", 12F);
            this.label14.Location = new System.Drawing.Point(34, 210);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 16);
            this.label14.TabIndex = 4;
            this.label14.Text = "500円：";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("MS UI Gothic", 12F);
            this.label16.Location = new System.Drawing.Point(26, 159);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(63, 16);
            this.label16.TabIndex = 3;
            this.label16.Text = "1000円：";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("MS UI Gothic", 12F);
            this.label13.Location = new System.Drawing.Point(26, 106);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 16);
            this.label13.TabIndex = 2;
            this.label13.Text = "5000円：";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Drawer10000
            // 
            this.Drawer10000.AutoSize = true;
            this.Drawer10000.Font = new System.Drawing.Font("MS UI Gothic", 12F);
            this.Drawer10000.Location = new System.Drawing.Point(18, 54);
            this.Drawer10000.Name = "Drawer10000";
            this.Drawer10000.Size = new System.Drawing.Size(71, 16);
            this.Drawer10000.TabIndex = 1;
            this.Drawer10000.Text = "10000円：";
            this.Drawer10000.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.label8.Location = new System.Drawing.Point(11, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(127, 22);
            this.label8.TabIndex = 0;
            this.label8.Text = "ドロワオープン";
            // 
            // Cancel0
            // 
            this.Cancel0.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.Cancel0.Location = new System.Drawing.Point(411, 40);
            this.Cancel0.Name = "Cancel0";
            this.Cancel0.Size = new System.Drawing.Size(62, 31);
            this.Cancel0.TabIndex = 61;
            this.Cancel0.Text = "×";
            this.Cancel0.UseVisualStyleBackColor = true;
            this.Cancel0.Click += new System.EventHandler(this.Cancel0_Click);
            // 
            // Line0_3
            // 
            this.Line0_3.BackColor = System.Drawing.Color.White;
            this.Line0_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line0_3.Location = new System.Drawing.Point(347, 40);
            this.Line0_3.Name = "Line0_3";
            this.Line0_3.Size = new System.Drawing.Size(86, 31);
            this.Line0_3.TabIndex = 60;
            // 
            // Line0_2
            // 
            this.Line0_2.BackColor = System.Drawing.Color.White;
            this.Line0_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line0_2.Location = new System.Drawing.Point(269, 40);
            this.Line0_2.Name = "Line0_2";
            this.Line0_2.Size = new System.Drawing.Size(86, 31);
            this.Line0_2.TabIndex = 59;
            // 
            // Line0_1
            // 
            this.Line0_1.BackColor = System.Drawing.Color.White;
            this.Line0_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line0_1.Location = new System.Drawing.Point(186, 40);
            this.Line0_1.Name = "Line0_1";
            this.Line0_1.Size = new System.Drawing.Size(86, 31);
            this.Line0_1.TabIndex = 58;
            // 
            // Line0_0
            // 
            this.Line0_0.BackColor = System.Drawing.Color.White;
            this.Line0_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line0_0.Location = new System.Drawing.Point(3, 40);
            this.Line0_0.Name = "Line0_0";
            this.Line0_0.Size = new System.Drawing.Size(191, 31);
            this.Line0_0.TabIndex = 57;
            // 
            // Cancel8
            // 
            this.Cancel8.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.Cancel8.Location = new System.Drawing.Point(411, 288);
            this.Cancel8.Name = "Cancel8";
            this.Cancel8.Size = new System.Drawing.Size(62, 31);
            this.Cancel8.TabIndex = 53;
            this.Cancel8.Text = "×";
            this.Cancel8.UseVisualStyleBackColor = true;
            this.Cancel8.Click += new System.EventHandler(this.Cancel8_Click);
            // 
            // Cancel7
            // 
            this.Cancel7.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.Cancel7.Location = new System.Drawing.Point(411, 257);
            this.Cancel7.Name = "Cancel7";
            this.Cancel7.Size = new System.Drawing.Size(62, 31);
            this.Cancel7.TabIndex = 56;
            this.Cancel7.Text = "×";
            this.Cancel7.UseVisualStyleBackColor = true;
            this.Cancel7.Click += new System.EventHandler(this.Cancel7_Click);
            // 
            // Cancel6
            // 
            this.Cancel6.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.Cancel6.Location = new System.Drawing.Point(411, 226);
            this.Cancel6.Name = "Cancel6";
            this.Cancel6.Size = new System.Drawing.Size(62, 31);
            this.Cancel6.TabIndex = 55;
            this.Cancel6.Text = "×";
            this.Cancel6.UseVisualStyleBackColor = true;
            this.Cancel6.Click += new System.EventHandler(this.Cancel6_Click);
            // 
            // Cancel5
            // 
            this.Cancel5.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.Cancel5.Location = new System.Drawing.Point(411, 195);
            this.Cancel5.Name = "Cancel5";
            this.Cancel5.Size = new System.Drawing.Size(62, 31);
            this.Cancel5.TabIndex = 53;
            this.Cancel5.Text = "×";
            this.Cancel5.UseVisualStyleBackColor = true;
            this.Cancel5.Click += new System.EventHandler(this.Cancel5_Click);
            // 
            // Cancel4
            // 
            this.Cancel4.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.Cancel4.Location = new System.Drawing.Point(411, 164);
            this.Cancel4.Name = "Cancel4";
            this.Cancel4.Size = new System.Drawing.Size(62, 31);
            this.Cancel4.TabIndex = 54;
            this.Cancel4.Text = "×";
            this.Cancel4.UseVisualStyleBackColor = true;
            this.Cancel4.Click += new System.EventHandler(this.Cancel4_Click);
            // 
            // Cancel2
            // 
            this.Cancel2.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.Cancel2.Location = new System.Drawing.Point(411, 102);
            this.Cancel2.Name = "Cancel2";
            this.Cancel2.Size = new System.Drawing.Size(62, 31);
            this.Cancel2.TabIndex = 53;
            this.Cancel2.Text = "×";
            this.Cancel2.UseVisualStyleBackColor = true;
            this.Cancel2.Click += new System.EventHandler(this.Cancel2_Click);
            // 
            // Cancel3
            // 
            this.Cancel3.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.Cancel3.Location = new System.Drawing.Point(411, 133);
            this.Cancel3.Name = "Cancel3";
            this.Cancel3.Size = new System.Drawing.Size(62, 31);
            this.Cancel3.TabIndex = 52;
            this.Cancel3.Text = "×";
            this.Cancel3.UseVisualStyleBackColor = true;
            this.Cancel3.Click += new System.EventHandler(this.Cancel3_Click);
            // 
            // Cancel1
            // 
            this.Cancel1.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.Cancel1.Location = new System.Drawing.Point(411, 71);
            this.Cancel1.Name = "Cancel1";
            this.Cancel1.Size = new System.Drawing.Size(62, 31);
            this.Cancel1.TabIndex = 51;
            this.Cancel1.Text = "×";
            this.Cancel1.UseVisualStyleBackColor = true;
            this.Cancel1.Click += new System.EventHandler(this.Cancel1_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(158)))), ((int)(((byte)(96)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label1.Location = new System.Drawing.Point(414, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 31);
            this.label1.TabIndex = 50;
            this.label1.Text = "Cncl";
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(158)))), ((int)(((byte)(96)))));
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label28.Location = new System.Drawing.Point(347, 14);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(70, 31);
            this.label28.TabIndex = 49;
            this.label28.Text = "合計";
            // 
            // Line8_3
            // 
            this.Line8_3.BackColor = System.Drawing.Color.White;
            this.Line8_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line8_3.Location = new System.Drawing.Point(347, 288);
            this.Line8_3.Name = "Line8_3";
            this.Line8_3.Size = new System.Drawing.Size(86, 31);
            this.Line8_3.TabIndex = 48;
            // 
            // Line7_3
            // 
            this.Line7_3.BackColor = System.Drawing.Color.LightGray;
            this.Line7_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line7_3.Location = new System.Drawing.Point(347, 257);
            this.Line7_3.Name = "Line7_3";
            this.Line7_3.Size = new System.Drawing.Size(86, 31);
            this.Line7_3.TabIndex = 47;
            // 
            // Line6_3
            // 
            this.Line6_3.BackColor = System.Drawing.Color.White;
            this.Line6_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line6_3.Location = new System.Drawing.Point(347, 226);
            this.Line6_3.Name = "Line6_3";
            this.Line6_3.Size = new System.Drawing.Size(86, 31);
            this.Line6_3.TabIndex = 46;
            // 
            // Line5_3
            // 
            this.Line5_3.BackColor = System.Drawing.Color.LightGray;
            this.Line5_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line5_3.Location = new System.Drawing.Point(347, 195);
            this.Line5_3.Name = "Line5_3";
            this.Line5_3.Size = new System.Drawing.Size(86, 31);
            this.Line5_3.TabIndex = 45;
            // 
            // Line4_3
            // 
            this.Line4_3.BackColor = System.Drawing.Color.White;
            this.Line4_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line4_3.Location = new System.Drawing.Point(347, 164);
            this.Line4_3.Name = "Line4_3";
            this.Line4_3.Size = new System.Drawing.Size(86, 31);
            this.Line4_3.TabIndex = 44;
            // 
            // Line3_3
            // 
            this.Line3_3.BackColor = System.Drawing.Color.LightGray;
            this.Line3_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line3_3.Location = new System.Drawing.Point(347, 133);
            this.Line3_3.Name = "Line3_3";
            this.Line3_3.Size = new System.Drawing.Size(86, 31);
            this.Line3_3.TabIndex = 43;
            // 
            // Line2_3
            // 
            this.Line2_3.BackColor = System.Drawing.Color.White;
            this.Line2_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line2_3.Location = new System.Drawing.Point(347, 102);
            this.Line2_3.Name = "Line2_3";
            this.Line2_3.Size = new System.Drawing.Size(86, 31);
            this.Line2_3.TabIndex = 42;
            // 
            // Line1_3
            // 
            this.Line1_3.BackColor = System.Drawing.Color.LightGray;
            this.Line1_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line1_3.Location = new System.Drawing.Point(347, 71);
            this.Line1_3.Name = "Line1_3";
            this.Line1_3.Size = new System.Drawing.Size(86, 31);
            this.Line1_3.TabIndex = 41;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(158)))), ((int)(((byte)(96)))));
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label27.Location = new System.Drawing.Point(269, 14);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(86, 31);
            this.label27.TabIndex = 40;
            this.label27.Text = "単価";
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(158)))), ((int)(((byte)(96)))));
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label26.Location = new System.Drawing.Point(186, 14);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(86, 31);
            this.label26.TabIndex = 39;
            this.label26.Text = "数量";
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(158)))), ((int)(((byte)(96)))));
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label25.Location = new System.Drawing.Point(3, 14);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(191, 31);
            this.label25.TabIndex = 38;
            this.label25.Text = "お買い上げ商品";
            // 
            // Line8_2
            // 
            this.Line8_2.BackColor = System.Drawing.Color.White;
            this.Line8_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line8_2.Location = new System.Drawing.Point(269, 288);
            this.Line8_2.Name = "Line8_2";
            this.Line8_2.Size = new System.Drawing.Size(86, 31);
            this.Line8_2.TabIndex = 37;
            // 
            // Line8_1
            // 
            this.Line8_1.BackColor = System.Drawing.Color.White;
            this.Line8_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line8_1.Location = new System.Drawing.Point(186, 288);
            this.Line8_1.Name = "Line8_1";
            this.Line8_1.Size = new System.Drawing.Size(86, 31);
            this.Line8_1.TabIndex = 36;
            // 
            // Line8_0
            // 
            this.Line8_0.BackColor = System.Drawing.Color.White;
            this.Line8_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line8_0.Location = new System.Drawing.Point(3, 288);
            this.Line8_0.Name = "Line8_0";
            this.Line8_0.Size = new System.Drawing.Size(191, 31);
            this.Line8_0.TabIndex = 35;
            // 
            // Line7_2
            // 
            this.Line7_2.BackColor = System.Drawing.Color.LightGray;
            this.Line7_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line7_2.Location = new System.Drawing.Point(269, 257);
            this.Line7_2.Name = "Line7_2";
            this.Line7_2.Size = new System.Drawing.Size(86, 31);
            this.Line7_2.TabIndex = 34;
            // 
            // Line7_1
            // 
            this.Line7_1.BackColor = System.Drawing.Color.LightGray;
            this.Line7_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line7_1.Location = new System.Drawing.Point(186, 257);
            this.Line7_1.Name = "Line7_1";
            this.Line7_1.Size = new System.Drawing.Size(86, 31);
            this.Line7_1.TabIndex = 33;
            // 
            // Line7_0
            // 
            this.Line7_0.BackColor = System.Drawing.Color.LightGray;
            this.Line7_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line7_0.Location = new System.Drawing.Point(3, 257);
            this.Line7_0.Name = "Line7_0";
            this.Line7_0.Size = new System.Drawing.Size(191, 31);
            this.Line7_0.TabIndex = 32;
            // 
            // Line6_2
            // 
            this.Line6_2.BackColor = System.Drawing.Color.White;
            this.Line6_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line6_2.Location = new System.Drawing.Point(269, 226);
            this.Line6_2.Name = "Line6_2";
            this.Line6_2.Size = new System.Drawing.Size(86, 31);
            this.Line6_2.TabIndex = 31;
            // 
            // Line6_1
            // 
            this.Line6_1.BackColor = System.Drawing.Color.White;
            this.Line6_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line6_1.Location = new System.Drawing.Point(186, 226);
            this.Line6_1.Name = "Line6_1";
            this.Line6_1.Size = new System.Drawing.Size(86, 31);
            this.Line6_1.TabIndex = 30;
            // 
            // Line6_0
            // 
            this.Line6_0.BackColor = System.Drawing.Color.White;
            this.Line6_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line6_0.Location = new System.Drawing.Point(3, 226);
            this.Line6_0.Name = "Line6_0";
            this.Line6_0.Size = new System.Drawing.Size(191, 31);
            this.Line6_0.TabIndex = 29;
            // 
            // Line5_2
            // 
            this.Line5_2.BackColor = System.Drawing.Color.LightGray;
            this.Line5_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line5_2.Location = new System.Drawing.Point(269, 195);
            this.Line5_2.Name = "Line5_2";
            this.Line5_2.Size = new System.Drawing.Size(86, 31);
            this.Line5_2.TabIndex = 28;
            // 
            // Line5_1
            // 
            this.Line5_1.BackColor = System.Drawing.Color.LightGray;
            this.Line5_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line5_1.Location = new System.Drawing.Point(186, 195);
            this.Line5_1.Name = "Line5_1";
            this.Line5_1.Size = new System.Drawing.Size(86, 31);
            this.Line5_1.TabIndex = 27;
            // 
            // Line5_0
            // 
            this.Line5_0.BackColor = System.Drawing.Color.LightGray;
            this.Line5_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line5_0.Location = new System.Drawing.Point(3, 195);
            this.Line5_0.Name = "Line5_0";
            this.Line5_0.Size = new System.Drawing.Size(191, 31);
            this.Line5_0.TabIndex = 26;
            // 
            // Line4_2
            // 
            this.Line4_2.BackColor = System.Drawing.Color.White;
            this.Line4_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line4_2.Location = new System.Drawing.Point(269, 164);
            this.Line4_2.Name = "Line4_2";
            this.Line4_2.Size = new System.Drawing.Size(86, 31);
            this.Line4_2.TabIndex = 25;
            // 
            // Line4_1
            // 
            this.Line4_1.BackColor = System.Drawing.Color.White;
            this.Line4_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line4_1.Location = new System.Drawing.Point(186, 164);
            this.Line4_1.Name = "Line4_1";
            this.Line4_1.Size = new System.Drawing.Size(86, 31);
            this.Line4_1.TabIndex = 24;
            // 
            // Line4_0
            // 
            this.Line4_0.BackColor = System.Drawing.Color.White;
            this.Line4_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line4_0.Location = new System.Drawing.Point(3, 164);
            this.Line4_0.Name = "Line4_0";
            this.Line4_0.Size = new System.Drawing.Size(191, 31);
            this.Line4_0.TabIndex = 23;
            // 
            // Line3_2
            // 
            this.Line3_2.BackColor = System.Drawing.Color.LightGray;
            this.Line3_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line3_2.Location = new System.Drawing.Point(269, 133);
            this.Line3_2.Name = "Line3_2";
            this.Line3_2.Size = new System.Drawing.Size(86, 31);
            this.Line3_2.TabIndex = 22;
            // 
            // Line3_1
            // 
            this.Line3_1.BackColor = System.Drawing.Color.LightGray;
            this.Line3_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line3_1.Location = new System.Drawing.Point(186, 133);
            this.Line3_1.Name = "Line3_1";
            this.Line3_1.Size = new System.Drawing.Size(86, 31);
            this.Line3_1.TabIndex = 21;
            // 
            // Line3_0
            // 
            this.Line3_0.BackColor = System.Drawing.Color.LightGray;
            this.Line3_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line3_0.Location = new System.Drawing.Point(3, 133);
            this.Line3_0.Name = "Line3_0";
            this.Line3_0.Size = new System.Drawing.Size(191, 31);
            this.Line3_0.TabIndex = 20;
            // 
            // Line2_2
            // 
            this.Line2_2.BackColor = System.Drawing.Color.White;
            this.Line2_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line2_2.Location = new System.Drawing.Point(269, 102);
            this.Line2_2.Name = "Line2_2";
            this.Line2_2.Size = new System.Drawing.Size(86, 31);
            this.Line2_2.TabIndex = 19;
            // 
            // Line2_1
            // 
            this.Line2_1.BackColor = System.Drawing.Color.White;
            this.Line2_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line2_1.Location = new System.Drawing.Point(186, 102);
            this.Line2_1.Name = "Line2_1";
            this.Line2_1.Size = new System.Drawing.Size(86, 31);
            this.Line2_1.TabIndex = 18;
            // 
            // Line2_0
            // 
            this.Line2_0.BackColor = System.Drawing.Color.White;
            this.Line2_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line2_0.Location = new System.Drawing.Point(3, 102);
            this.Line2_0.Name = "Line2_0";
            this.Line2_0.Size = new System.Drawing.Size(191, 31);
            this.Line2_0.TabIndex = 17;
            // 
            // Line1_2
            // 
            this.Line1_2.BackColor = System.Drawing.Color.LightGray;
            this.Line1_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line1_2.Location = new System.Drawing.Point(269, 71);
            this.Line1_2.Name = "Line1_2";
            this.Line1_2.Size = new System.Drawing.Size(86, 31);
            this.Line1_2.TabIndex = 16;
            // 
            // Line1_1
            // 
            this.Line1_1.BackColor = System.Drawing.Color.LightGray;
            this.Line1_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line1_1.Location = new System.Drawing.Point(186, 71);
            this.Line1_1.Name = "Line1_1";
            this.Line1_1.Size = new System.Drawing.Size(86, 31);
            this.Line1_1.TabIndex = 8;
            // 
            // Line1_0
            // 
            this.Line1_0.BackColor = System.Drawing.Color.LightGray;
            this.Line1_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Line1_0.Location = new System.Drawing.Point(3, 71);
            this.Line1_0.Name = "Line1_0";
            this.Line1_0.Size = new System.Drawing.Size(191, 31);
            this.Line1_0.TabIndex = 2;
            // 
            // topic01
            // 
            this.topic01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.topic01.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.topic01.Location = new System.Drawing.Point(19, 3);
            this.topic01.Name = "topic01";
            this.topic01.Size = new System.Drawing.Size(80, 69);
            this.topic01.TabIndex = 5;
            this.topic01.Text = "赤グラスワイン";
            this.topic01.UseVisualStyleBackColor = false;
            this.topic01.Click += new System.EventHandler(this.topic_Click);
            // 
            // topic02
            // 
            this.topic02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.topic02.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.topic02.Location = new System.Drawing.Point(19, 78);
            this.topic02.Name = "topic02";
            this.topic02.Size = new System.Drawing.Size(80, 69);
            this.topic02.TabIndex = 6;
            this.topic02.Text = "辛味チキン";
            this.topic02.UseVisualStyleBackColor = false;
            this.topic02.Click += new System.EventHandler(this.topic_Click);
            // 
            // topic03
            // 
            this.topic03.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.topic03.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.topic03.Location = new System.Drawing.Point(19, 153);
            this.topic03.Name = "topic03";
            this.topic03.Size = new System.Drawing.Size(80, 69);
            this.topic03.TabIndex = 7;
            this.topic03.Text = "ポテトのグリル";
            this.topic03.UseVisualStyleBackColor = false;
            this.topic03.Click += new System.EventHandler(this.topic_Click);
            // 
            // topic06
            // 
            this.topic06.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.topic06.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.topic06.Location = new System.Drawing.Point(105, 153);
            this.topic06.Name = "topic06";
            this.topic06.Size = new System.Drawing.Size(80, 69);
            this.topic06.TabIndex = 10;
            this.topic06.Text = "ほうれん草のソテー";
            this.topic06.UseVisualStyleBackColor = false;
            this.topic06.Click += new System.EventHandler(this.topic_Click);
            // 
            // topic05
            // 
            this.topic05.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.topic05.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.topic05.Location = new System.Drawing.Point(105, 78);
            this.topic05.Name = "topic05";
            this.topic05.Size = new System.Drawing.Size(80, 69);
            this.topic05.TabIndex = 9;
            this.topic05.Text = "わかめのサラダ";
            this.topic05.UseVisualStyleBackColor = false;
            this.topic05.Click += new System.EventHandler(this.topic_Click);
            // 
            // topic04
            // 
            this.topic04.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.topic04.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.topic04.Location = new System.Drawing.Point(105, 3);
            this.topic04.Name = "topic04";
            this.topic04.Size = new System.Drawing.Size(80, 69);
            this.topic04.TabIndex = 8;
            this.topic04.Text = "小エビのサラダ";
            this.topic04.UseVisualStyleBackColor = false;
            this.topic04.Click += new System.EventHandler(this.topic_Click);
            // 
            // topic12
            // 
            this.topic12.BackColor = System.Drawing.Color.DarkOrange;
            this.topic12.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.topic12.Location = new System.Drawing.Point(277, 153);
            this.topic12.Name = "topic12";
            this.topic12.Size = new System.Drawing.Size(80, 69);
            this.topic12.TabIndex = 16;
            this.topic12.Text = "ミートソース";
            this.topic12.UseVisualStyleBackColor = false;
            this.topic12.Click += new System.EventHandler(this.topic_Click);
            // 
            // topic11
            // 
            this.topic11.BackColor = System.Drawing.Color.DarkOrange;
            this.topic11.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.topic11.Location = new System.Drawing.Point(277, 78);
            this.topic11.Name = "topic11";
            this.topic11.Size = new System.Drawing.Size(80, 69);
            this.topic11.TabIndex = 15;
            this.topic11.Text = "ペペロンチーノ";
            this.topic11.UseVisualStyleBackColor = false;
            this.topic11.Click += new System.EventHandler(this.topic_Click);
            // 
            // topic10
            // 
            this.topic10.BackColor = System.Drawing.Color.DarkOrange;
            this.topic10.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.topic10.Location = new System.Drawing.Point(277, 3);
            this.topic10.Name = "topic10";
            this.topic10.Size = new System.Drawing.Size(80, 69);
            this.topic10.TabIndex = 14;
            this.topic10.Text = "カルボナーラ";
            this.topic10.UseVisualStyleBackColor = false;
            this.topic10.Click += new System.EventHandler(this.topic_Click);
            // 
            // topic09
            // 
            this.topic09.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(198)))), ((int)(((byte)(188)))));
            this.topic09.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.topic09.Location = new System.Drawing.Point(191, 153);
            this.topic09.Name = "topic09";
            this.topic09.Size = new System.Drawing.Size(80, 69);
            this.topic09.TabIndex = 13;
            this.topic09.Text = "ソーセージピザ";
            this.topic09.UseVisualStyleBackColor = false;
            this.topic09.Click += new System.EventHandler(this.topic_Click);
            // 
            // topic08
            // 
            this.topic08.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(198)))), ((int)(((byte)(188)))));
            this.topic08.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.topic08.Location = new System.Drawing.Point(191, 78);
            this.topic08.Name = "topic08";
            this.topic08.Size = new System.Drawing.Size(80, 69);
            this.topic08.TabIndex = 12;
            this.topic08.Text = "ミラノ風ドリア";
            this.topic08.UseVisualStyleBackColor = false;
            this.topic08.Click += new System.EventHandler(this.topic_Click);
            // 
            // topic07
            // 
            this.topic07.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(198)))), ((int)(((byte)(188)))));
            this.topic07.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.topic07.Location = new System.Drawing.Point(191, 3);
            this.topic07.Name = "topic07";
            this.topic07.Size = new System.Drawing.Size(80, 69);
            this.topic07.TabIndex = 11;
            this.topic07.Text = "マルゲリータ";
            this.topic07.UseVisualStyleBackColor = false;
            this.topic07.Click += new System.EventHandler(this.topic_Click);
            // 
            // topic15
            // 
            this.topic15.BackColor = System.Drawing.Color.Goldenrod;
            this.topic15.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.topic15.Location = new System.Drawing.Point(363, 153);
            this.topic15.Name = "topic15";
            this.topic15.Size = new System.Drawing.Size(80, 69);
            this.topic15.TabIndex = 19;
            this.topic15.Text = "フォッカチオ";
            this.topic15.UseVisualStyleBackColor = false;
            this.topic15.Click += new System.EventHandler(this.topic_Click);
            // 
            // topic14
            // 
            this.topic14.BackColor = System.Drawing.Color.Goldenrod;
            this.topic14.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.topic14.Location = new System.Drawing.Point(363, 78);
            this.topic14.Name = "topic14";
            this.topic14.Size = new System.Drawing.Size(80, 69);
            this.topic14.TabIndex = 18;
            this.topic14.Text = "ミックスグリル";
            this.topic14.UseVisualStyleBackColor = false;
            this.topic14.Click += new System.EventHandler(this.topic_Click);
            // 
            // topic13
            // 
            this.topic13.BackColor = System.Drawing.Color.Goldenrod;
            this.topic13.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.topic13.Location = new System.Drawing.Point(363, 3);
            this.topic13.Name = "topic13";
            this.topic13.Size = new System.Drawing.Size(80, 69);
            this.topic13.TabIndex = 17;
            this.topic13.Text = "ハンバーグステーキ";
            this.topic13.UseVisualStyleBackColor = false;
            this.topic13.Click += new System.EventHandler(this.topic_Click);
            // 
            // topic18
            // 
            this.topic18.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.topic18.Location = new System.Drawing.Point(449, 153);
            this.topic18.Name = "topic18";
            this.topic18.Size = new System.Drawing.Size(80, 69);
            this.topic18.TabIndex = 22;
            this.topic18.Text = "ドリンクバー";
            this.topic18.UseVisualStyleBackColor = true;
            // 
            // topic17
            // 
            this.topic17.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.topic17.Location = new System.Drawing.Point(449, 78);
            this.topic17.Name = "topic17";
            this.topic17.Size = new System.Drawing.Size(80, 69);
            this.topic17.TabIndex = 21;
            this.topic17.Text = "ティラミスクラシコ";
            this.topic17.UseVisualStyleBackColor = true;
            this.topic17.Click += new System.EventHandler(this.topic_Click);
            // 
            // topic16
            // 
            this.topic16.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.topic16.Location = new System.Drawing.Point(449, 3);
            this.topic16.Name = "topic16";
            this.topic16.Size = new System.Drawing.Size(80, 69);
            this.topic16.TabIndex = 20;
            this.topic16.Text = "イタリアンジェラート";
            this.topic16.UseVisualStyleBackColor = true;
            this.topic16.Click += new System.EventHandler(this.topic_Click);
            // 
            // OrderPanel
            // 
            this.OrderPanel.Controls.Add(this.topic01);
            this.OrderPanel.Controls.Add(this.topic18);
            this.OrderPanel.Controls.Add(this.topic02);
            this.OrderPanel.Controls.Add(this.topic17);
            this.OrderPanel.Controls.Add(this.topic03);
            this.OrderPanel.Controls.Add(this.topic16);
            this.OrderPanel.Controls.Add(this.topic04);
            this.OrderPanel.Controls.Add(this.topic15);
            this.OrderPanel.Controls.Add(this.topic05);
            this.OrderPanel.Controls.Add(this.topic14);
            this.OrderPanel.Controls.Add(this.topic06);
            this.OrderPanel.Controls.Add(this.topic13);
            this.OrderPanel.Controls.Add(this.topic07);
            this.OrderPanel.Controls.Add(this.topic12);
            this.OrderPanel.Controls.Add(this.topic08);
            this.OrderPanel.Controls.Add(this.topic11);
            this.OrderPanel.Controls.Add(this.topic09);
            this.OrderPanel.Controls.Add(this.topic10);
            this.OrderPanel.Location = new System.Drawing.Point(-5, 394);
            this.OrderPanel.Name = "OrderPanel";
            this.OrderPanel.Size = new System.Drawing.Size(545, 227);
            this.OrderPanel.TabIndex = 23;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.label2.Location = new System.Drawing.Point(55, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 27);
            this.label2.TabIndex = 24;
            this.label2.Text = "合計：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label3.Location = new System.Drawing.Point(74, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 24);
            this.label3.TabIndex = 25;
            this.label3.Text = "小計：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS UI Gothic", 14F);
            this.label4.Location = new System.Drawing.Point(75, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 19);
            this.label4.TabIndex = 26;
            this.label4.Text = "外税：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS UI Gothic", 17F);
            this.label5.Location = new System.Drawing.Point(3, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 23);
            this.label5.TabIndex = 27;
            this.label5.Text = "金額";
            // 
            // casher
            // 
            this.casher.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.casher.Controls.Add(this.DrawerButton);
            this.casher.Controls.Add(this.decision);
            this.casher.Controls.Add(this.pmnt);
            this.casher.Controls.Add(this.ErrorCage);
            this.casher.Controls.Add(this.subtotal);
            this.casher.Controls.Add(this.tax);
            this.casher.Controls.Add(this.back);
            this.casher.Controls.Add(this.total);
            this.casher.Controls.Add(this.label7);
            this.casher.Controls.Add(this.label6);
            this.casher.Controls.Add(this.label4);
            this.casher.Controls.Add(this.label2);
            this.casher.Controls.Add(this.label5);
            this.casher.Controls.Add(this.label3);
            this.casher.Location = new System.Drawing.Point(555, 411);
            this.casher.Name = "casher";
            this.casher.Size = new System.Drawing.Size(338, 210);
            this.casher.TabIndex = 28;
            // 
            // DrawerButton
            // 
            this.DrawerButton.BackColor = System.Drawing.SystemColors.Control;
            this.DrawerButton.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.DrawerButton.Location = new System.Drawing.Point(271, 9);
            this.DrawerButton.Name = "DrawerButton";
            this.DrawerButton.Size = new System.Drawing.Size(54, 93);
            this.DrawerButton.TabIndex = 30;
            this.DrawerButton.Text = "ドロワ";
            this.DrawerButton.UseVisualStyleBackColor = false;
            this.DrawerButton.Click += new System.EventHandler(this.DrawerButton_Click);
            // 
            // decision
            // 
            this.decision.BackColor = System.Drawing.SystemColors.Control;
            this.decision.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.decision.Location = new System.Drawing.Point(271, 108);
            this.decision.Name = "decision";
            this.decision.Size = new System.Drawing.Size(54, 93);
            this.decision.TabIndex = 39;
            this.decision.Text = "お支払";
            this.decision.UseVisualStyleBackColor = false;
            this.decision.Click += new System.EventHandler(this.decision_Click);
            // 
            // pmnt
            // 
            this.pmnt.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.pmnt.Location = new System.Drawing.Point(133, 112);
            this.pmnt.Name = "pmnt";
            this.pmnt.Size = new System.Drawing.Size(108, 23);
            this.pmnt.TabIndex = 37;
            this.pmnt.Text = "0";
            this.pmnt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ErrorCage
            // 
            this.ErrorCage.BackColor = System.Drawing.SystemColors.Window;
            this.ErrorCage.Font = new System.Drawing.Font("MS UI Gothic", 16F);
            this.ErrorCage.Location = new System.Drawing.Point(11, 171);
            this.ErrorCage.Name = "ErrorCage";
            this.ErrorCage.Size = new System.Drawing.Size(254, 30);
            this.ErrorCage.TabIndex = 36;
            // 
            // subtotal
            // 
            this.subtotal.Font = new System.Drawing.Font("MS UI Gothic", 14F);
            this.subtotal.Location = new System.Drawing.Point(133, 61);
            this.subtotal.Name = "subtotal";
            this.subtotal.Size = new System.Drawing.Size(108, 23);
            this.subtotal.TabIndex = 35;
            this.subtotal.Text = "0";
            this.subtotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tax
            // 
            this.tax.Font = new System.Drawing.Font("MS UI Gothic", 14F);
            this.tax.Location = new System.Drawing.Point(133, 84);
            this.tax.Name = "tax";
            this.tax.Size = new System.Drawing.Size(108, 21);
            this.tax.TabIndex = 34;
            this.tax.Text = "0";
            this.tax.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // back
            // 
            this.back.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.back.Location = new System.Drawing.Point(133, 143);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(108, 23);
            this.back.TabIndex = 33;
            this.back.Text = "0";
            this.back.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // total
            // 
            this.total.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.total.Location = new System.Drawing.Point(133, 24);
            this.total.Name = "total";
            this.total.Size = new System.Drawing.Size(108, 23);
            this.total.TabIndex = 31;
            this.total.Text = "0";
            this.total.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.label7.Location = new System.Drawing.Point(43, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 27);
            this.label7.TabIndex = 29;
            this.label7.Text = "お釣り：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.label6.Location = new System.Drawing.Point(11, 108);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 27);
            this.label6.TabIndex = 28;
            this.label6.Text = "お支払い：";
            // 
            // Restaurant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(912, 630);
            this.Controls.Add(this.casher);
            this.Controls.Add(this.OrderPanel);
            this.Controls.Add(this.commodity);
            this.Controls.Add(this.payent);
            this.Name = "Restaurant";
            this.Text = "Form1";
            this.payent.ResumeLayout(false);
            this.payent.PerformLayout();
            this.cashPanel.ResumeLayout(false);
            this.cashPanel.PerformLayout();
            this.eMoneyPanel.ResumeLayout(false);
            this.commodity.ResumeLayout(false);
            this.commodity.PerformLayout();
            this.MenuPanel.ResumeLayout(false);
            this.DrawerPanel.ResumeLayout(false);
            this.DrawerPanel.PerformLayout();
            this.OrderPanel.ResumeLayout(false);
            this.casher.ResumeLayout(false);
            this.casher.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RadioButton cash;
        private System.Windows.Forms.RadioButton emoney;
        private System.Windows.Forms.GroupBox payent;
        private System.Windows.Forms.Panel commodity;
        private System.Windows.Forms.Button topic01;
        private System.Windows.Forms.Button topic02;
        private System.Windows.Forms.Button topic03;
        private System.Windows.Forms.Button topic06;
        private System.Windows.Forms.Button topic05;
        private System.Windows.Forms.Button topic04;
        private System.Windows.Forms.Button topic12;
        private System.Windows.Forms.Button topic11;
        private System.Windows.Forms.Button topic10;
        private System.Windows.Forms.Button topic09;
        private System.Windows.Forms.Button topic08;
        private System.Windows.Forms.Button topic07;
        private System.Windows.Forms.Button topic15;
        private System.Windows.Forms.Button topic14;
        private System.Windows.Forms.Button topic13;
        private System.Windows.Forms.Button topic18;
        private System.Windows.Forms.Button topic17;
        private System.Windows.Forms.Button topic16;
        private System.Windows.Forms.Panel eMoneyPanel;
        private System.Windows.Forms.Button mn9;
        private System.Windows.Forms.Button mn8;
        private System.Windows.Forms.Button mn7;
        private System.Windows.Forms.Button mn6;
        private System.Windows.Forms.Button mn5;
        private System.Windows.Forms.Button mn4;
        private System.Windows.Forms.Button mn3;
        private System.Windows.Forms.Button mn2;
        private System.Windows.Forms.Button mn1;
        private System.Windows.Forms.Button mn0;
        private System.Windows.Forms.Button mn00;
        private System.Windows.Forms.Button mn10;
        private System.Windows.Forms.Panel MenuPanel;
        private System.Windows.Forms.Label Line1_0;
        private System.Windows.Forms.Label Line1_1;
        private System.Windows.Forms.Label Line1_2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label Line8_2;
        private System.Windows.Forms.Label Line8_1;
        private System.Windows.Forms.Label Line8_0;
        private System.Windows.Forms.Label Line7_2;
        private System.Windows.Forms.Label Line7_1;
        private System.Windows.Forms.Label Line7_0;
        private System.Windows.Forms.Label Line6_2;
        private System.Windows.Forms.Label Line6_1;
        private System.Windows.Forms.Label Line6_0;
        private System.Windows.Forms.Label Line5_2;
        private System.Windows.Forms.Label Line5_1;
        private System.Windows.Forms.Label Line5_0;
        private System.Windows.Forms.Label Line4_2;
        private System.Windows.Forms.Label Line4_1;
        private System.Windows.Forms.Label Line4_0;
        private System.Windows.Forms.Label Line3_2;
        private System.Windows.Forms.Label Line3_1;
        private System.Windows.Forms.Label Line3_0;
        private System.Windows.Forms.Label Line2_2;
        private System.Windows.Forms.Label Line2_1;
        private System.Windows.Forms.Label Line2_0;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label Line8_3;
        private System.Windows.Forms.Label Line7_3;
        private System.Windows.Forms.Label Line6_3;
        private System.Windows.Forms.Label Line5_3;
        private System.Windows.Forms.Label Line4_3;
        private System.Windows.Forms.Label Line3_3;
        private System.Windows.Forms.Label Line2_3;
        private System.Windows.Forms.Label Line1_3;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button Cancel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Cancel8;
        private System.Windows.Forms.Button Cancel7;
        private System.Windows.Forms.Button Cancel6;
        private System.Windows.Forms.Button Cancel5;
        private System.Windows.Forms.Button Cancel4;
        private System.Windows.Forms.Button Cancel2;
        private System.Windows.Forms.Button Cancel3;
        private System.Windows.Forms.Panel OrderPanel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel casher;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label total;
        private System.Windows.Forms.Label subtotal;
        private System.Windows.Forms.Label tax;
        private System.Windows.Forms.Label back;
        private System.Windows.Forms.Label ErrorCage;
        private System.Windows.Forms.Panel cashPanel;
        private System.Windows.Forms.TextBox sheet_10k;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button sheet10kDown;
        private System.Windows.Forms.Button sheet10kUp;
        private System.Windows.Forms.Button sheet5000Down;
        private System.Windows.Forms.Button sheet5000Up;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox sheet5000;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button coin50Down;
        private System.Windows.Forms.Button coin50Up;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button coin100Down;
        private System.Windows.Forms.Button coin100Up;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox coin100;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button coin500Down;
        private System.Windows.Forms.Button coin500Up;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox coin500;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button sheet1000Down;
        private System.Windows.Forms.Button sheet1000Up;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox sheet1000;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button coin5Down;
        private System.Windows.Forms.Button coin5Up;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox coin5;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button coin10Down;
        private System.Windows.Forms.Button coin10Up;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox coin10;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button coin1Down;
        private System.Windows.Forms.Button coin1Up;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox coin1;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button Cancel0;
        private System.Windows.Forms.Label Line0_3;
        private System.Windows.Forms.Label Line0_2;
        private System.Windows.Forms.Label Line0_1;
        private System.Windows.Forms.Label Line0_0;
        private System.Windows.Forms.Label pmnt;
        private System.Windows.Forms.Button rmv;
        private System.Windows.Forms.TextBox coin50;
        private System.Windows.Forms.Button decision;
        private System.Windows.Forms.Panel DrawerPanel;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label Drawer10000;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button DrawerButton;
        private System.Windows.Forms.Button modoru;
        private System.Windows.Forms.Button tsuri_supply;
        private System.Windows.Forms.Label Warning;
        private System.Windows.Forms.TextBox dr50;
        private System.Windows.Forms.TextBox dr10000;
        private System.Windows.Forms.TextBox dr100;
        private System.Windows.Forms.TextBox dr500;
        private System.Windows.Forms.TextBox dr1000;
        private System.Windows.Forms.TextBox dr5000;
        private System.Windows.Forms.TextBox dr1;
        private System.Windows.Forms.TextBox dr5;
        private System.Windows.Forms.TextBox dr10;
        private System.Windows.Forms.Button DrawerClose;
    }
}

